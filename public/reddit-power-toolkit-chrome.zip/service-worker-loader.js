import './assets/service-worker.ts.B9kh0eYm.js';
