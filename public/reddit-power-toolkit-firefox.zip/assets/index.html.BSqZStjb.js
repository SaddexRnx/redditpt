import{t as n,A as j,s as v,i as N}from"./i18n.AC_-_lbT.js";import{r as c,j as e,c as C,R as M}from"./client.gxHn_UGl.js";import{t as R,e as L,u as _,p as A}from"./storage.CBHWZwDD.js";/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const S=t=>t.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),b=(...t)=>t.filter((s,r,i)=>!!s&&s.trim()!==""&&i.indexOf(s)===r).join(" ").trim();/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */var T={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const E=c.forwardRef(({color:t="currentColor",size:s=24,strokeWidth:r=2,absoluteStrokeWidth:i,className:d="",children:l,iconNode:g,...h},u)=>c.createElement("svg",{ref:u,...T,width:s,height:s,stroke:t,strokeWidth:i?Number(r)*24/Number(s):r,className:b("lucide",d),...h},[...g.map(([w,y])=>c.createElement(w,y)),...Array.isArray(l)?l:[l]]));/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const o=(t,s)=>{const r=c.forwardRef(({className:i,...d},l)=>c.createElement(E,{ref:l,iconNode:s,className:b(`lucide-${S(t)}`,i),...d}));return r.displayName=`${t}`,r};/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const I=o("ChartColumn",[["path",{d:"M3 3v16a2 2 0 0 0 2 2h16",key:"c24i48"}],["path",{d:"M18 17V9",key:"2bz60n"}],["path",{d:"M13 17V5",key:"1frdt8"}],["path",{d:"M8 17v-3",key:"17ska0"}]]);/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const P=o("Command",[["path",{d:"M15 6v12a3 3 0 1 0 3-3H6a3 3 0 1 0 3 3V6a3 3 0 1 0-3 3h12a3 3 0 1 0-3-3",key:"11bfej"}]]);/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const q=o("ExternalLink",[["path",{d:"M15 3h6v6",key:"1q9fwt"}],["path",{d:"M10 14 21 3",key:"gplh6r"}],["path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6",key:"a6xqqp"}]]);/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const $=o("Image",[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",ry:"2",key:"1m3agn"}],["circle",{cx:"9",cy:"9",r:"2",key:"af1f0g"}],["path",{d:"m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21",key:"1xmnt7"}]]);/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const H=o("ListTree",[["path",{d:"M21 12h-8",key:"1bmf0i"}],["path",{d:"M21 6H8",key:"1pqkrb"}],["path",{d:"M21 18h-8",key:"1tm79t"}],["path",{d:"M3 6v4c0 1.1.9 2 2 2h3",key:"1ywdgy"}],["path",{d:"M3 10v6c0 1.1.9 2 2 2h3",key:"2wc746"}]]);/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const B=o("Power",[["path",{d:"M12 2v10",key:"mnfbl"}],["path",{d:"M18.4 6.6a9 9 0 1 1-12.77.04",key:"obofu9"}]]);/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const f=o("RefreshCcw",[["path",{d:"M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8",key:"14sxne"}],["path",{d:"M3 3v5h5",key:"1xhq8a"}],["path",{d:"M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16",key:"1hlbsb"}],["path",{d:"M16 16h5v5",key:"ccwih5"}]]);/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const F=o("Rows2",[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",key:"afitv7"}],["path",{d:"M3 12h18",key:"1i2n21"}]]);/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const V=o("Settings2",[["path",{d:"M20 7h-9",key:"3s1dr2"}],["path",{d:"M14 17H5",key:"gfn3mx"}],["circle",{cx:"17",cy:"17",r:"3",key:"18b49y"}],["circle",{cx:"7",cy:"7",r:"3",key:"dfmy0x"}]]);/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const z=o("Sparkles",[["path",{d:"M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z",key:"4pj2yx"}],["path",{d:"M20 3v4",key:"1olli1"}],["path",{d:"M22 5h-4",key:"1gvqau"}],["path",{d:"M4 17v2",key:"vumght"}],["path",{d:"M5 18H3",key:"zchphs"}]]);async function x(){const[t]=await chrome.tabs.query({active:!0,currentWindow:!0});return t}const G=(t="")=>/^https?:\/\/([a-z]+\.)?reddit\.com\//.test(t);async function O(t){try{const[s]=await chrome.scripting.executeScript({target:{tabId:t},func:()=>({loaded:!!window.__RPT_LOADED__})});return{ok:!0,loaded:s.result.loaded}}catch(s){return{ok:!1,error:String(s?.message||s)}}}function m(t){return x().then(s=>{if(s?.id)return chrome.scripting.executeScript({target:{tabId:s.id},func:t}).catch(()=>{})})}function D(){const[t,s]=c.useState(!0),[r,i]=c.useState("dark"),[d,l]=c.useState("en"),[g,h]=c.useState("notReddit"),u=c.useCallback(async()=>{const a=await x();if(!G(a?.url))return h("notReddit");if(!a?.id)return h("injectFail");const k=await O(a.id);if(!k.ok)return h("injectFail");h(k.loaded?"active":"notInjected")},[]);c.useEffect(()=>{(async()=>(s(await R()),i(await L()),chrome.storage.local.get("rpt_lang",a=>l(a.rpt_lang||"en")),u()))()},[u]);const w=a=>{i(a),A(a),document.documentElement.setAttribute("data-rpt-theme",a)},y=async()=>{const a=await x();a?.id&&(chrome.tabs.reload(a.id),setTimeout(()=>window.close(),200))};return e.jsxs("div",{className:"p-4 space-y-3",children:[e.jsxs("header",{className:"flex items-center justify-between",children:[e.jsxs("div",{children:[e.jsx("div",{className:"text-base font-bold tracking-tight",children:n("appName")}),e.jsx("div",{className:"text-[11px] text-muted",children:n("tagline")})]}),e.jsxs("div",{className:"flex items-center gap-1.5",children:[e.jsx("select",{value:d,onChange:a=>{l(a.target.value),v(a.target.value)},className:"rpt-input h-7 w-auto text-xs px-2","aria-label":n("language"),children:j.map(([a,k])=>e.jsx("option",{value:a,children:a.toUpperCase()},a))}),e.jsx("button",{className:"rpt-btn h-7 w-7 p-0","aria-label":n("theme"),onClick:()=>w(r==="dark"?"light":"dark"),children:r==="dark"?"☾":"☀"})]})]}),e.jsx(U,{state:g,onReload:y,onRefresh:u}),e.jsxs("section",{className:"rpt-card flex items-center justify-between",children:[e.jsxs("div",{children:[e.jsx("div",{className:"text-sm font-semibold",children:n("enable_toolkit")}),e.jsx("div",{className:"text-[11px] text-muted mt-0.5",children:t?n("status_active"):n("toolkit_paused")})]}),e.jsx("button",{onClick:()=>{const a=!t;s(a),_(a)},role:"switch","aria-checked":t,className:`w-11 h-6 rounded-full relative transition-colors ${t?"bg-accent":"bg-panel-3"}`,children:e.jsx("span",{className:`absolute top-0.5 w-5 h-5 rounded-full bg-white transition-transform ${t?"translate-x-[22px]":"translate-x-0.5"}`})})]}),e.jsxs("section",{className:"grid grid-cols-2 gap-2",children:[e.jsx(p,{icon:e.jsx(z,{className:"w-4 h-4"}),label:"Summary",onClick:()=>m(()=>window.RPT?.features?.summary?.open?.())}),e.jsx(p,{icon:e.jsx($,{className:"w-4 h-4"}),label:"Gallery",onClick:()=>m(()=>window.RPT?.features?.gallery?.open?.())}),e.jsx(p,{icon:e.jsx(F,{className:"w-4 h-4"}),label:"Collapse",onClick:()=>m(()=>window.RPT?.features?.folding?.collapseAll?.())}),e.jsx(p,{icon:e.jsx(H,{className:"w-4 h-4"}),label:"Conversation",onClick:()=>m(()=>window.RPT?.features?.conversation?.open?.())}),e.jsx(p,{icon:e.jsx(P,{className:"w-4 h-4"}),label:"Command",onClick:()=>m(()=>window.RPT?.features?.cmdk?.open?.())}),e.jsx(p,{icon:e.jsx(f,{className:"w-4 h-4"}),label:"Resync",onClick:()=>m(()=>window.RPT?.ui?.resync?.())})]}),e.jsxs("section",{className:"grid grid-cols-2 gap-2",children:[e.jsxs("button",{className:"rpt-btn",onClick:()=>chrome.runtime.openOptionsPage(),children:[e.jsx(V,{className:"w-4 h-4"})," ",n("settings")]}),e.jsxs("button",{className:"rpt-btn",onClick:()=>chrome.tabs.create({url:chrome.runtime.getURL("src/pages/analytics/index.html")}),children:[e.jsx(I,{className:"w-4 h-4"})," ",n("analytics")]})]}),e.jsxs("button",{className:"rpt-btn-primary w-full",onClick:async()=>{const a=await x();a?.id&&chrome.tabs.sendMessage(a.id,{type:"rpt:togglePanel"}).catch(()=>{})},children:[e.jsx(B,{className:"w-4 h-4"})," ",n("open_panel")]}),e.jsxs("footer",{className:"flex items-center justify-between text-[11px] text-muted pt-1",children:[e.jsx("span",{children:n("footer_privacy")}),e.jsxs("a",{className:"inline-flex items-center gap-1 hover:text-accent",href:"https://github.com/Saddexrnx/redditpt",target:"_blank",rel:"noreferrer",children:["GitHub ",e.jsx(q,{className:"w-3 h-3"})]})]})]})}function U({state:t,onReload:s,onRefresh:r}){const i={active:"bg-success",notReddit:"bg-warn",notInjected:"bg-warn",injectFail:"bg-danger"},d={active:n("status_active"),notReddit:n("status_notReddit"),notInjected:n("status_notInjected"),injectFail:n("status_injectFail")};return e.jsxs("div",{className:"rpt-card flex items-center gap-2 py-2.5",children:[e.jsx("span",{className:`w-2 h-2 rounded-full ${i[t]}`,"aria-hidden":!0}),e.jsx("span",{className:"text-xs flex-1",children:d[t]}),t==="notInjected"&&e.jsx("button",{className:"rpt-btn h-7 text-xs",onClick:s,children:n("reload_tab")}),e.jsx("button",{className:"rpt-btn h-7 w-7 p-0","aria-label":"Refresh",onClick:r,children:e.jsx(f,{className:"w-3.5 h-3.5"})})]})}function p({icon:t,label:s,onClick:r}){return e.jsxs("button",{className:"rpt-btn flex-col h-auto py-2.5",onClick:()=>{r(),window.close()},children:[t,e.jsx("span",{className:"text-[11px]",children:s})]})}await N();C(document.getElementById("root")).render(e.jsx(M.StrictMode,{children:e.jsx(D,{})}));
