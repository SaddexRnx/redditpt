(function(){if(!window.RPT)return;const x=window.RPT,u=x.v2={modules:{}},A=a=>window.RPT_I18N?.t(a)||a,h=a=>window.RPT_I18N?.text(a)||a,b={get(a,n){return new Promise(t=>chrome.storage.local.get({[a]:n},e=>t(e[a])))},set(a,n){return new Promise(t=>chrome.storage.local.set({[a]:n},t))},async patch(a,n,t){const e=await this.get(a,n),o=t({...e});return await this.set(a,o),o}};u._storage=b;const l=a=>x.utils.escapeHtml(a),V=()=>Math.random().toString(36).slice(2,10);function k(a,n,t={}){document.querySelectorAll(".rpt-v2-modal").forEach(o=>o.remove());const e=document.createElement("div");return e.className="rpt-overlay rpt-v2-modal",e.setAttribute("role","dialog"),e.setAttribute("aria-modal","true"),e.setAttribute("aria-label",h(a)),e.innerHTML=`
      <div class="rpt-overlay-panel rpt-v2-panel" style="max-width:${t.wide?960:720}px">
        <div class="rpt-overlay-head">
          <h2 style="display:flex;align-items:center;gap:10px">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></svg>
            <span>${l(h(a))}</span>
          </h2>
          <button class="rpt-close" aria-label="${A("close")}">${x.ICON.close}</button>
        </div>
        <div class="rpt-v2-body">${n}</div>
      </div>`,e.querySelector(".rpt-close").onclick=()=>e.remove(),e.addEventListener("click",o=>{o.target===e&&e.remove()}),document.body.appendChild(e),x.a11y.trapModal(e),e}u._modal=k;function j(a,n,t){const e=new Blob([t],{type:n}),o=URL.createObjectURL(e),s=document.createElement("a");s.href=o,s.download=a,s.click(),setTimeout(()=>URL.revokeObjectURL(o),500)}u._download=j;function f(a){let n=document.querySelector(".rpt-toast");n||(n=document.createElement("div"),n.className="rpt-toast",document.body.appendChild(n)),n.textContent=h(a),n.classList.add("show"),clearTimeout(n._t),n._t=setTimeout(()=>n.classList.remove("show"),1800)}u._toast=f;function q(){const a=document.querySelectorAll('shreddit-post, article[data-testid="post-container"], .thing.link, [data-ks-item]'),n=[];return a.forEach(t=>{const e=t.getAttribute?.("post-title")||t.querySelector?.('a[slot="full-post-link"], a[data-click-id="body"], a.title')?.textContent?.trim()||t.querySelector?.("h1, h2, h3")?.textContent?.trim()||"",o=t.getAttribute?.("author")||t.querySelector?.('a[href*="/user/"]')?.textContent?.trim()||"",s=parseInt(t.getAttribute?.("score")||t.querySelector?.('[data-testid="post-score"]')?.textContent||"0",10)||0,r=parseInt(t.getAttribute?.("comment-count")||t.querySelector?.('a[data-click-id="comments"]')?.textContent||"0",10)||0,i=t.getAttribute?.("permalink")||t.querySelector?.('a[slot="full-post-link"], a[data-click-id="body"], a.title')?.getAttribute("href")||"",d=t.getAttribute?.("domain")||t.querySelector?.(".domain a")?.textContent?.trim()||"",c=t.querySelector?.('[slot="post-flair"], .linkflairlabel')?.textContent?.trim()||"",p=t.getAttribute?.("post-type")||(t.querySelector?.("img, video")?t.querySelector("video")?"video":"image":d?"link":"text"),g=t.getAttribute?.("created-timestamp")||"",y=t.getAttribute?.("nsfw")==="true"||t.classList?.contains("over18")||!!t.querySelector?.('[data-testid="nsfw-tag"]'),$=t.getAttribute?.("spoiler")==="true"||!!t.querySelector?.('[data-testid="spoiler-tag"]');n.push({title:e,author:o,score:s,comments:r,permalink:i,domain:d,flair:c,type:p,created:g,nsfw:y,spoiler:$,el:t})}),n}u._collectPosts=q;function C(){const a=location.pathname.match(/\/r\/([^/]+)/);return a?a[1]:""}u._sub=C;async function R(a,n="hot"){const t=q(),e=a||C();if(!e||!window.RPT_API)return t;let o=[];try{const[r,i]=await Promise.all([window.RPT_API.posts(e,n,{limit:100}),n==="new"?Promise.resolve([]):window.RPT_API.posts(e,"new",{limit:100})]),d=new Map;[...r,...i].forEach(c=>{d.has(c.id)||d.set(c.id,c)}),o=[...d.values()]}catch{}if(!o.length)return t;const s=new Map(t.map(r=>[String(r.permalink||"").replace(/^https?:\/\/[^/]+/,""),r.el]));return o.forEach(r=>{const i=String(r.permalink||"").replace(/^https?:\/\/[^/]+/,""),d=s.get(i);d&&(r.el=d)}),o}u._postsLive=R;async function X(a,n,t){const e=k(a,`<p class="rpt-muted">${l(h("Loading live data from Reddit"))}…</p>`,n||{});try{const o=await t(),s=e.querySelector(".rpt-v2-body");return s&&(s.innerHTML=o),e}catch{const s=e.querySelector(".rpt-v2-body");return s&&(s.innerHTML=`<p class="rpt-muted">${l(h("Couldn't reach Reddit — falling back to on-page data."))}</p>`),e}}u._withLoading=X,u.modules.communityCompare={id:"communityCompare",name:"Community comparison",desc:"Snapshot the current subreddit and compare with saved snapshots.",KEY:"rpt_v2_communities",snapshot(){return this._buildSnap(q())},async snapshotLive(){const a=C();if(!a)return null;const n=await R(a,"hot"),t=this._buildSnap(n);try{const e=await window.RPT_API?.about?.(a);e&&(t.members=e.subscribers,t.online=e.active_user_count??e.accounts_active,t.created=e.created_utc?new Date(e.created_utc*1e3).toISOString():t.created,t.description=e.public_description||e.description||t.description,t.isNsfw=!!e.over18,t.subType=e.subreddit_type||"")}catch{}return t},_buildSnap(a){const n=C();if(!n)return null;const t={};a.forEach(y=>{(y.title.toLowerCase().match(/[a-z]{4,}/g)||[]).forEach($=>t[$]=(t[$]||0)+1)});const e=Object.entries(t).sort((y,$)=>$[1]-y[1]).slice(0,12).map(([y,$])=>({w:y,c:$})),o={},s={},r={text:0,image:0,video:0,link:0};a.forEach(y=>{y.flair&&(o[y.flair]=(o[y.flair]||0)+1),y.domain&&(s[y.domain]=(s[y.domain]||0)+1),r[y.type]!=null&&r[y.type]++});const i={};a.forEach(y=>{y.author&&(i[y.author]=(i[y.author]||0)+1)});const d=document.querySelector("shreddit-subreddit-header, .titlebox .md")?.innerText?.slice(0,400)||"",c=document.querySelector('[data-testid="subreddit-subscribers"], .subscribers .number')?.textContent?.trim()||"",p=document.querySelector('shreddit-subreddit-header [name="created"], .titlebox .age time')?.getAttribute?.("datetime")||"";return{sub:n,sampledAt:new Date().toISOString(),posts:a.length,avgComments:a.length?Math.round(a.reduce((y,$)=>y+$.comments,0)/a.length):0,avgScore:a.length?Math.round(a.reduce((y,$)=>y+$.score,0)/a.length):0,types:r,flairs:o,domains:s,topKeywords:e,topAuthors:Object.entries(i).sort((y,$)=>$[1]-y[1]).slice(0,10),description:d,members:c,created:p}},async open(){const a=await b.get(this.KEY,{}),n=await this.snapshotLive(),t=Object.values(a),e=t.map(r=>`
        <tr>
          <td><input type="checkbox" data-cmp="${l(r.sub)}"></td>
          <td><strong>r/${l(r.sub)}</strong><div class="rpt-muted" style="font-size:11px">${new Date(r.sampledAt).toLocaleString()}</div></td>
          <td>${r.posts}</td>
          <td>${r.avgScore}</td>
          <td>${r.avgComments}</td>
          <td>${r.types.image}/${r.types.video}/${r.types.link}/${r.types.text}</td>
          <td><button data-del="${l(r.sub)}" class="rpt-mini">🗑</button></td>
        </tr>`).join(""),o=`
        <div class="rpt-v2-section">
          ${n?`<button class="rpt-v2-primary" data-act="save">📸 Snapshot r/${l(n.sub)} (${n.posts} posts)</button>`:'<p class="rpt-muted">Open a subreddit page (/r/…) to capture a snapshot.</p>'}
        </div>
        <div class="rpt-v2-section">
          <h3>Saved snapshots</h3>
          ${t.length?`<table class="rpt-v2-table"><thead><tr><th></th><th>Subreddit</th><th>Posts</th><th>Avg score</th><th>Avg comm.</th><th>img/vid/link/txt</th><th></th></tr></thead><tbody>${e}</tbody></table>
          <button class="rpt-v2-primary" data-act="compare">Compare selected</button>`:'<p class="rpt-muted">No snapshots yet.</p>'}
        </div>
        <div class="rpt-v2-section" id="rpt-cmp-result"></div>`,s=k("Community comparison",o,{wide:!0});s.querySelector('[data-act="save"]')?.addEventListener("click",async()=>{await b.patch(this.KEY,{},r=>(r[n.sub]=n,r)),f("Snapshot saved"),this.open()}),s.querySelectorAll("[data-del]").forEach(r=>r.onclick=async()=>{await b.patch(this.KEY,{},i=>(delete i[r.dataset.del],i)),this.open()}),s.querySelector('[data-act="compare"]')?.addEventListener("click",()=>{const r=[...s.querySelectorAll("[data-cmp]:checked")].map(i=>a[i.dataset.cmp]);if(r.length<2)return f("Pick at least 2 snapshots");s.querySelector("#rpt-cmp-result").innerHTML=this.render(r)})},render(a){const n=(t,e=!0)=>[...a].sort((s,r)=>e?r[t]-s[t]:s[t]-r[t])[0].sub;return`<h3>Result</h3>
        <div class="rpt-v2-cmp-grid">
          <div><strong>Most posts loaded:</strong> r/${l(n("posts"))}</div>
          <div><strong>Highest avg score:</strong> r/${l(n("avgScore"))}</div>
          <div><strong>Most discussion:</strong> r/${l(n("avgComments"))}</div>
          <div><strong>Most images:</strong> r/${l([...a].sort((t,e)=>e.types.image-t.types.image)[0].sub)}</div>
          <div><strong>Most videos:</strong> r/${l([...a].sort((t,e)=>e.types.video-t.types.video)[0].sub)}</div>
          <div><strong>Most links:</strong> r/${l([...a].sort((t,e)=>e.types.link-t.types.link)[0].sub)}</div>
          <div><strong>Most text-heavy:</strong> r/${l([...a].sort((t,e)=>e.types.text-t.types.text)[0].sub)}</div>
        </div>
        <details style="margin-top:12px"><summary>Raw data (JSON)</summary><pre class="rpt-v2-pre">${l(JSON.stringify(a,null,2))}</pre></details>`},run(){this.open()}},u.modules.miniMap={id:"miniMap",name:"Comment tree mini-map",desc:"Visual overview of the full comment tree with click-to-jump.",open(){const a=x.state.tree||x.features.commentTree.parse();if(!a?.length){f("Open a Reddit thread first");return}const n=r=>1+(r.children||[]).reduce((i,d)=>i+n(d),0),t=r=>1+Math.max(0,...(r.children||[]).map(t)),e=r=>`<ul class="rpt-mm-ul">${r.map(i=>{const d=n(i),c=t(i);return`<li>
          <button class="rpt-mm-node ${d>=8?"rpt-mm-big":""}" data-id="${l(i.id)}" title="${l(i.author)} · ${d} in branch · depth ${c}">
            <span class="rpt-mm-dot" style="background:${x.utils.authorColor(i.author)}"></span>
            <span class="rpt-mm-au">${l(i.author)}</span>
            <span class="rpt-mm-sz">${d}</span>
          </button>
          ${i.children?.length?e(i.children):""}
        </li>`}).join("")}</ul>`,o=`
        <p class="rpt-muted">Click any node to jump. Larger dots = branches with more replies.</p>
        <div class="rpt-mm-wrap">${e(a)}</div>`,s=k("Comment tree mini-map",o,{wide:!0});s.querySelectorAll(".rpt-mm-node").forEach(r=>r.onclick=()=>{const i=document.getElementById(r.dataset.id)||document.querySelector(`[thingid="${r.dataset.id}"]`);i&&(i.scrollIntoView({behavior:"smooth",block:"center"}),i.classList.add("rpt-flash"),setTimeout(()=>i.classList.remove("rpt-flash"),1400),s.remove())})},run(){this.open()}},u.modules.commentExport={id:"commentExport",name:"Selective comment export",desc:"Pick individual comments or a branch and export in md/html/json/txt.",open(){x.features.commentTree.parse();const a=x.state.tree||[],n=[],t=(r,i=0)=>{n.push({...r,depth:i}),(r.children||[]).forEach(d=>t(d,i+1))};a.forEach(r=>t(r));const e=`
        <div class="rpt-btnrow">
          <button class="rpt-v2-primary" data-act="all">Select all</button>
          <button class="rpt-v2-primary" data-act="none">Clear</button>
          <span style="flex:1"></span>
          <select id="rpt-ex-fmt"><option>markdown</option><option>html</option><option>json</option><option>plain</option></select>
          <button class="rpt-v2-primary" data-act="export">Export selected</button>
        </div>
        <div class="rpt-ex-list">
          ${n.map(r=>`<label class="rpt-ex-row" style="padding-left:${r.depth*14}px">
            <input type="checkbox" data-cid="${l(r.id)}">
            <span class="rpt-ex-au" style="color:${x.utils.authorColor(r.author)}">${l(r.author)}</span>
            <span class="rpt-ex-sc">▲${r.score||0}</span>
            <span class="rpt-ex-tx">${l((r.body||"").slice(0,120))}</span>
          </label>`).join("")}
        </div>`,o=k("Selective comment export",e,{wide:!0}),s=r=>o.querySelectorAll("[data-cid]").forEach(i=>i.checked=r);o.querySelector('[data-act="all"]').onclick=()=>s(!0),o.querySelector('[data-act="none"]').onclick=()=>s(!1),o.querySelector('[data-act="export"]').onclick=()=>{const r=new Set([...o.querySelectorAll("[data-cid]:checked")].map(p=>p.dataset.cid)),i=n.filter(p=>r.has(p.id));if(!i.length)return f("Pick at least one comment");const d=o.querySelector("#rpt-ex-fmt").value,c=x.state.post||{title:document.title,url:location.href};d==="json"?j(`rpt-comments-${Date.now()}.json`,"application/json",JSON.stringify({post:c,exportedAt:new Date().toISOString(),comments:i},null,2)):d==="plain"?j(`rpt-comments-${Date.now()}.txt`,"text/plain",`${c.title||""}
${c.url||""}

`+i.map(p=>`${" ".repeat(p.depth*2)}${p.author} (▲${p.score||0}): ${p.body}`).join(`

`)):d==="html"?j(`rpt-comments-${Date.now()}.html`,"text/html",`<h1>${l(c.title||"")}</h1><p><a href="${l(c.url||"")}">${l(c.url||"")}</a></p>`+i.map(p=>`<blockquote style="margin-left:${p.depth*20}px"><b>${l(p.author)}</b> ▲${p.score||0}<br>${l(p.body).replace(/\n/g,"<br>")}</blockquote>`).join("")):j(`rpt-comments-${Date.now()}.md`,"text/markdown",`# ${c.title||""}
${c.url||""}

`+i.map(p=>`${"  ".repeat(p.depth)}- **${p.author}** (▲${p.score||0}): ${p.body.replace(/\n/g," ")}`).join(`

`)),f("Exported"),o.remove()}},run(){this.open()}},u.modules.bookmarks={id:"bookmarks",name:"Advanced bookmarks",desc:"Folders, tags, notes, and search across saved Reddit content.",KEY:"rpt_v2_bookmarks",async addCurrent(a="post"){const n={id:V(),kind:a,url:location.href,title:document.title,folder:"Inbox",tags:[],notes:"",addedAt:Date.now()};await b.patch(this.KEY,{items:[]},t=>(t.items.push(n),t)),f("Bookmarked to Inbox")},async open(){const a=await b.get(this.KEY,{items:[]}),t=`
        <div class="rpt-btnrow">
          <button class="rpt-v2-primary" data-act="add">＋ Bookmark this page</button>
          <input id="rpt-bm-q" placeholder="Search title, tag, note…" style="flex:1">
          <select id="rpt-bm-folder"><option value="">All folders</option>${[...new Set(["Inbox",...a.items.map(s=>s.folder)])].map(s=>`<option>${l(s)}</option>`).join("")}</select>
          <button class="rpt-v2-primary" data-act="export">Export JSON</button>
        </div>
        <div class="rpt-bm-list"></div>`,e=k("Advanced bookmarks",t,{wide:!0}),o=async()=>{const s=await b.get(this.KEY,{items:[]}),r=e.querySelector("#rpt-bm-q").value.toLowerCase(),i=e.querySelector("#rpt-bm-folder").value,d=s.items.filter(c=>(!i||c.folder===i)&&(!r||`${c.title} ${c.tags.join(" ")} ${c.notes}`.toLowerCase().includes(r))).sort((c,p)=>p.addedAt-c.addedAt);e.querySelector(".rpt-bm-list").innerHTML=d.map(c=>`
          <div class="rpt-bm-item" data-id="${c.id}">
            <div><span class="rpt-tag">${l(c.kind)}</span> <a href="${l(c.url)}" target="_blank" rel="noopener">${l(c.title)}</a></div>
            <div class="rpt-bm-meta">
              <input data-k="folder" value="${l(c.folder)}" placeholder="Folder">
              <input data-k="tags" value="${l(c.tags.join(", "))}" placeholder="tags, comma sep">
              <input data-k="notes" value="${l(c.notes)}" placeholder="Notes">
              <button data-act="del">🗑</button>
            </div>
          </div>`).join("")||'<p class="rpt-muted">No bookmarks match.</p>',e.querySelectorAll(".rpt-bm-item").forEach(c=>{c.querySelectorAll("input").forEach(p=>p.onchange=async()=>{await b.patch(this.KEY,{items:[]},g=>{const y=g.items.find($=>$.id===c.dataset.id);return y&&(p.dataset.k==="tags"?y.tags=p.value.split(",").map($=>$.trim()).filter(Boolean):y[p.dataset.k]=p.value),g})}),c.querySelector('[data-act="del"]').onclick=async()=>{await b.patch(this.KEY,{items:[]},p=>(p.items=p.items.filter(g=>g.id!==c.dataset.id),p)),o()}})};e.querySelector('[data-act="add"]').onclick=async()=>{await this.addCurrent(),o()},e.querySelector('[data-act="export"]').onclick=async()=>{const s=await b.get(this.KEY,{items:[]});j(`rpt-bookmarks-${Date.now()}.json`,"application/json",JSON.stringify(s,null,2))},e.querySelector("#rpt-bm-q").oninput=o,e.querySelector("#rpt-bm-folder").onchange=o,o()},run(){this.open()}},u.modules.userAnalytics={id:"userAnalytics",name:"User analytics on hover",desc:"Hover a username to see thread stats + personal notes / tags.",KEY:"rpt_v2_user_notes",_card:null,_hideTimer:null,async _show(a,n,t){x.features.commentTree.parse();const e=[];(x.state.tree||[]).forEach(function c(p){e.push(p),(p.children||[]).forEach(c)});const o=e.filter(c=>c.author===t),s=e.filter(c=>o.some(p=>(p.children||[]).some(g=>g.id===c.id))),r=o.length?Math.round(o.reduce((c,p)=>c+(p.body||"").length,0)/o.length):0,i=(await b.get(this.KEY,{}))[t]||{note:"",tag:""};this._card||(this._card=document.createElement("div"),this._card.className="rpt-v2-usercard",this._card.addEventListener("mouseenter",()=>clearTimeout(this._hideTimer)),this._card.addEventListener("mouseleave",()=>this._hide()),document.body.appendChild(this._card));const d=c=>{this._card.innerHTML=`
        <div class="rpt-uc-head">
          <span class="rpt-uc-dot" style="background:${x.utils.authorColor(t)}"></span>
          <strong>u/${l(t)}</strong>
          ${c?.is_gold?'<span class="rpt-tag" style="background:#f6a700;color:#111">Premium</span>':""}
          ${c?.verified?'<span class="rpt-tag">Verified</span>':""}
          ${i.tag?`<span class="rpt-tag">${l(i.tag)}</span>`:""}
        </div>
        <div class="rpt-uc-grid">
          ${c?`
          <div><small>${l(h("Post karma"))}</small><strong>${c.link_karma??"—"}</strong></div>
          <div><small>${l(h("Comment karma"))}</small><strong>${c.comment_karma??"—"}</strong></div>
          <div><small>${l(h("Account age"))}</small><strong>${c.created_utc?Math.floor((Date.now()/1e3-c.created_utc)/86400/365*10)/10+"y":"—"}</strong></div>`:""}
          <div><small>Comments here</small><strong>${o.length}</strong></div>
          <div><small>Replies received</small><strong>${s.length}</strong></div>
          <div><small>Avg length</small><strong>${r}c</strong></div>
        </div>
        <textarea class="rpt-uc-note" placeholder="Private note (local only)">${l(i.note)}</textarea>
        <input class="rpt-uc-tag" placeholder="Tag (e.g. helpful, expert)" value="${l(i.tag)}">
        <button class="rpt-uc-save rpt-v2-primary">Save note</button>`,this._card.querySelector(".rpt-uc-save").onclick=async()=>{const p=this._card.querySelector(".rpt-uc-note").value,g=this._card.querySelector(".rpt-uc-tag").value;await b.patch(this.KEY,{},y=>(y[t]={note:p,tag:g},y)),f("Note saved")}};d(null),this._card.style.left=Math.min(window.innerWidth-300,a+12)+"px",this._card.style.top=Math.min(window.innerHeight-260,n+12)+"px",this._card.style.display="block";try{const c=await window.RPT_API?.user?.(t);c&&d(c)}catch{}},_hide(){this._hideTimer=setTimeout(()=>{this._card&&(this._card.style.display="none")},260)},enabled:!1,enable(){this.enabled||(this.enabled=!0,document.addEventListener("mouseover",a=>{const n=a.target.closest?.('a[href*="/user/"], a[href*="/u/"], [data-testid="comment_author_link"]');if(!n)return;const t=(n.getAttribute("href")||"").split("/user/")[1]?.split("/")[0]||n.textContent.trim();if(!t)return;clearTimeout(this._hideTimer);const e=n.getBoundingClientRect();this._show(e.right,e.bottom,t)},!0),document.addEventListener("mouseout",a=>{this._card&&!a.relatedTarget?.closest?.(".rpt-v2-usercard")&&!a.target.closest?.(".rpt-v2-usercard")&&this._hide()},!0))},run(){this.enable(),f("Hover any username to see analytics")}},u.modules.postAnalytics={id:"postAnalytics",name:"Post analytics on hover",desc:"Rich hover card for posts on listing pages.",_card:null,enabled:!1,enable(){this.enabled||(this.enabled=!0,document.addEventListener("mouseover",a=>{const n=a.target.closest?.('shreddit-post, article[data-testid="post-container"], .thing.link');if(!n)return;const e=q().find(i=>i.el===n);if(!e)return;this._card||(this._card=document.createElement("div"),this._card.className="rpt-v2-postcard",document.body.appendChild(this._card));const o=i=>{const d=i?.score??e.score,c=i?.comments??e.comments,p=c?Math.round(c/Math.max(1,d)*100):0,g=i?.upvoteRatio!=null?Math.round(i.upvoteRatio*100)+"%":"—";this._card.innerHTML=`
            <div class="rpt-uc-head"><strong>${l((i?.title||e.title).slice(0,80))}</strong></div>
            <div class="rpt-uc-grid">
              <div><small>Score</small><strong>▲${d}</strong></div>
              <div><small>Comments</small><strong>${c}</strong></div>
              <div><small>${l(h("Upvote ratio"))}</small><strong>${g}</strong></div>
              <div><small>${l(h("Awards"))}</small><strong>${i?.awards??0}</strong></div>
              <div><small>Engage</small><strong>${p}%</strong></div>
              <div><small>Type</small><strong>${l(i?.type||e.type)}</strong></div>
              <div><small>Domain</small><strong>${l(i?.domain||e.domain||"self")}</strong></div>
              <div><small>Flair</small><strong>${l(i?.flair||e.flair||"—")}</strong></div>
            </div>`};o(null);const s=n.getBoundingClientRect();this._card.style.left=Math.min(window.innerWidth-320,s.right+8)+"px",this._card.style.top=Math.max(8,s.top)+"px",this._card.style.display="block";const r=window.RPT_API?.permalinkToId?.(e.permalink);r&&window.RPT_API&&window.RPT_API.comments(r,{limit:1,depth:0}).then(i=>{i&&this._card?.style.display!=="none"&&o(i.post)}).catch(()=>{})},!0),document.addEventListener("mouseleave",()=>{this._card&&(this._card.style.display="none")},!0))},run(){this.enable(),f("Hover any post to see analytics")}},u.modules.subAnalyzer={id:"subAnalyzer",name:"Subreddit analyzer dashboard",desc:"Full breakdown of the current subreddit from loaded data.",async _harvest(a,n={}){n.force&&window.RPT_API&&window.RPT_API.clearCache(`/r/${a}/`),window.RPT_API&&window.RPT_API.tag("subAnalyzer");const t=await R(a,"hot"),e=Date.now(),o=u.modules.communityCompare.snapshot()||{},s=w=>document.querySelector(w),r=s("shreddit-subreddit-header"),i=r?.getAttribute?.("subscribers")||s("faceplate-number[pretty]")?.getAttribute?.("number")||s('[data-testid="subreddit-subscribers"]')?.textContent||s(".subscribers .number")?.textContent||o.members||"",d=r?.getAttribute?.("active")||s('[id^="IdCard--ActiveMembers"]')?.textContent||s(".users-online .number")?.textContent||"",c=r?.getAttribute?.("created-timestamp")||s('shreddit-subreddit-header [name="created"]')?.getAttribute?.("datetime")||s('faceplate-date-format[format="MMM DD, YYYY"]')?.getAttribute?.("datetime")||s(".titlebox .age time")?.getAttribute?.("datetime")||o.created||"",p=r?.getAttribute?.("is-nsfw")==="true"||!!s('shreddit-subreddit-header [data-testid="subreddit-nsfw"]'),g=r?.getAttribute?.("subreddit-type")==="private"||!!s('[data-testid="subreddit-private"]'),y=r?.getAttribute?.("description")||s('shreddit-subreddit-header [slot="description"]')?.textContent?.trim()||s(".titlebox .md")?.innerText?.trim()||o.description||"",$=Array.from(document.querySelectorAll('[data-testid="moderator-list"] a, .titlebox .list-item a[href*="/user/"]')).map(w=>w.textContent.trim().replace(/^u\//,"")).filter(Boolean).slice(0,12),M=document.querySelectorAll('shreddit-rule, [data-testid="subreddit-rule"], .side .titlebox ol li').length;let _={},S=[],P=[],O=0,Y=0;if(window.RPT_API){const[w,E]=await Promise.all([window.RPT_API.aboutWithFallback(a,{module:"subAnalyzer",force:!!n.force}),window.RPT_API.rulesWithFallback(a,{module:"subAnalyzer",force:!!n.force})]);O=Date.now(),Y=Date.now(),S=w.sources,P=E.sources;const T=w.data||{};_={members:T.subscribers,online:T.active_user_count??T.accounts_active,created:T.created_utc?T.created_utc*1e3:null,description:T.public_description||T.description||"",isNsfw:!!T.over18,isPrivate:T.subreddit_type==="private"||T.subreddit_type==="restricted",rulesCount:E.rules.length,rules:E.rules.slice(0,20).map(st=>st.short_name||""),rulesDetail:E.rules.slice(0,20),title:T.title||"",lang:T.lang||"",type:T.subreddit_type||""}}const D=t.map(w=>w.score).sort((w,E)=>w-E),F=D.length?D[Math.floor(D.length/2)]:0,K=D.length?D[D.length-1]:0,B=t.filter(w=>w.nsfw).length,I=t.filter(w=>w.spoiler).length,m={};t.forEach(w=>{w.author&&w.author!=="[deleted]"&&(m[w.author]=(m[w.author]||0)+1)});const v=Object.entries(m).sort((w,E)=>E[1]-w[1]).slice(0,10),L=new Array(24).fill(0);let N=0;t.forEach(w=>{if(!w.created)return;const E=new Date(w.created);isNaN(E)||(L[E.getHours()]++,N++)});const Z=N?L.indexOf(Math.max(...L)):-1,W=Date.now(),J=new Array(7).fill(0),G=[];for(let w=6;w>=0;w--){const E=new Date(W-w*864e5);G.push(E.toLocaleDateString(void 0,{weekday:"short",day:"numeric"}))}t.forEach(w=>{if(!w.created)return;const E=new Date(w.created).getTime(),T=6-Math.floor((W-E)/864e5);T>=0&&T<7&&J[T]++});const tt=[...t].sort((w,E)=>E.score-w.score).slice(0,5),et=[...t].sort((w,E)=>E.comments-w.comments).slice(0,5);return{sub:a,snap:o,posts:t,members:_.members??(i?String(i).trim():""),online:_.online??(d?String(d).trim():""),created:_.created||c,isNsfw:_.isNsfw||p,isPrivate:_.isPrivate||g,description:_.description||y,mods:$,rulesCount:_.rulesCount||M,rules:_.rules||[],rulesDetail:_.rulesDetail||[],title:_.title||"",lang:_.lang||"",type:_.type||"",median:F,max:K,nsfwCount:B,spoilerCount:I,topAuthors:v,hours:L,peakHour:Z,dated:N,days:J,dayLabels:G,topByScore:tt,topByComments:et,_diag:{aboutSources:S,rulesSources:P,postsAt:e,aboutAt:O,rulesAt:Y}}},async open(a={}){const n=C();if(!n)return f(A("open_subreddit_page")||"Open a subreddit page");k(`${h("Subreddit analyzer dashboard")} — r/${n}`,`<p class="rpt-muted">${h("Loading live data from Reddit")}…</p>`,{wide:!0});const t=await this._harvest(n,a),e=t.snap,o=t.posts.length||e.posts||0,s=m=>{if(!m)return"—";const v=new Date(m);if(isNaN(v))return l(m);try{return v.toLocaleDateString(void 0,{year:"numeric",month:"short",day:"numeric"})}catch{return v.toISOString().slice(0,10)}},r=m=>m?new Date(m).toLocaleTimeString():"—",i=(m,v,L)=>`<div class="rpt-card"><div class="rpt-k">${l(h(m))}</div><div class="rpt-v">${v}</div>${L?`<div class="rpt-src">${l(L)}</div>`:""}</div>`,d=(m,v)=>`<span class="rpt-stat-chip">${l(m)}<em>${v}</em></span>`,c=Object.entries(e.flairs||{}).sort((m,v)=>v[1]-m[1]),p=Object.entries(e.domains||{}).sort((m,v)=>v[1]-m[1]).slice(0,12),g=e.topKeywords||[],y=e.types||{text:0,image:0,video:0,link:0},$=Object.entries(y).map(([m,v])=>{const L=o?Math.round(v/o*100):0;return`<div class="rpt-bar-row"><span>${l(h(m))}</span>
          <div class="rpt-bar"><i style="width:${L}%"></i></div><b>${v} · ${L}%</b></div>`}).join(""),M=U(t.hours,{labels:Array.from({length:24},(m,v)=>String(v)),h:120,unit:A("posts")||"posts",ariaLabel:h("Posting activity by hour")}),_=U(t.days,{labels:t.dayLabels,h:120,unit:A("posts")||"posts",ariaLabel:h("Daily posting trend (last 7 days)")}),S=t.dated?`${M}<p class="rpt-muted" style="margin:6px 0 0">${A("peak_hour")||"Peak hour"}: <strong>${t.peakHour}:00</strong> · ${t.dated}/${o} ${A("with_dates")||"with dates"}</p>`:`<p class="rpt-muted">${A("no_dated_posts")||"No dated posts on this page."}</p>`,P=(m,v,L)=>m.length?`<ul class="rpt-linklist">${m.map(N=>`
        <li><a href="${l(N.permalink||"#")}" target="_blank" rel="noopener">${l(N.title||"(untitled)")}</a>
          <span class="rpt-muted"> · ${v(N)} ${l(h(L))} · u/${l(N.author||"?")}</span></li>`).join("")}</ul>`:`<p class="rpt-muted">${A("none")||"None"}</p>`,O=m=>{if(m==null||m==="")return"—";const v=Number(m);return isFinite(v)?v>=1e6?(v/1e6).toFixed(1).replace(/\.0$/,"")+"M":v>=1e3?(v/1e3).toFixed(1).replace(/\.0$/,"")+"k":String(v):String(m)},Y=[t.isNsfw?'<span class="rpt-badge-off">NSFW 18+</span>':"",t.isPrivate?`<span class="rpt-badge-off">${A("private")||"Private"}</span>`:""].filter(Boolean).join(" "),D=m=>`<li>
        <span class="rpt-src-dot ${m.ok?"ok":"bad"}"></span>
        <code>${l(m.url)}</code>
        <span class="rpt-muted"> · ${m.ok?h("ok"):h("empty")}</span>
        ${m.fields?`<span class="rpt-muted"> · ${l(Object.entries(m.fields).map(([v,L])=>`${v}=${L??"—"}`).join(", "))}</span>`:""}
      </li>`,F=`
        <div class="rpt-sources">
          <h5>${l(h("Data sources"))}</h5>
          <ul>${(t._diag.aboutSources||[]).concat(t._diag.rulesSources||[]).map(D).join("")}</ul>
        </div>`,K=(m,v)=>`<span class="rpt-stamp">${l(h(m))}: <b>${r(v)}</b></span>`,B=`
        <div class="rpt-analyzer-toolbar">
          <div class="rpt-stamps">
            ${K("Posts",t._diag.postsAt)}
            ${K("About",t._diag.aboutAt)}
            ${K("Rules",t._diag.rulesAt)}
          </div>
          <button class="rpt-v2-primary" data-act="refresh" aria-label="${l(h("Refresh live data"))}">${l(h("Refresh live data"))}</button>
        </div>

        <div class="rpt-sub-head">
          <div>
            <h3 style="margin:0 0 4px">r/${l(n)} ${Y}</h3>
            <p class="rpt-muted" style="margin:0">${l(t.description).slice(0,320)||l(A("no_description")||"No description available.")}</p>
          </div>
        </div>

        <h4 class="rpt-section-title">${l(h("Overview"))}</h4>
        <div class="rpt-metric-grid">
          ${i("Members",l(O(t.members)),"about.json → data.subscribers")}
          ${i("Online now",l(O(t.online)),"about.json → data.active_user_count")}
          ${i("Created",s(t.created),"about.json → data.created_utc")}
          ${i("Rules",t.rulesCount||"—","about/rules.json → rules.length")}
          ${i("Posts loaded",o)}
          ${i("Avg score",e.avgScore??0)}
          ${i("Median score",t.median)}
          ${i("Top score",t.max)}
          ${i("Avg comments",e.avgComments??0)}
          ${i("NSFW posts",t.nsfwCount)}
          ${i("Spoilers",t.spoilerCount)}
          ${i("Unique authors",Object.keys(t.topAuthors.reduce((m,[v])=>(m[v]=1,m),{})).length||t.topAuthors.length)}
        </div>

        <h4 class="rpt-section-title">${l(h("Content types"))}</h4>
        <div class="rpt-bars">${$}</div>

        <h4 class="rpt-section-title">${l(h("Posting activity by hour"))}</h4>
        ${S}

        <h4 class="rpt-section-title">${l(h("Daily posting trend (last 7 days)"))}</h4>
        ${_}

        <h4 class="rpt-section-title">${l(h("Top authors on this page"))}</h4>
        <div class="rpt-chips-v">${t.topAuthors.length?t.topAuthors.map(([m,v])=>d(`u/${m}`,v)).join(""):`<p class="rpt-muted">${h("None")}</p>`}</div>

        <h4 class="rpt-section-title">${l(h("Top flairs"))}</h4>
        <div class="rpt-chips-v">${c.length?c.slice(0,10).map(([m,v])=>d(m,v)).join(""):`<p class="rpt-muted">${h("None")}</p>`}</div>

        <h4 class="rpt-section-title">${l(h("Top domains"))}</h4>
        <div class="rpt-chips-v">${p.length?p.map(([m,v])=>d(m,v)).join(""):`<p class="rpt-muted">${h("None")}</p>`}</div>

        <h4 class="rpt-section-title">${l(h("Popular keywords"))}</h4>
        <div class="rpt-chips-v">${g.length?g.map(m=>d(m.w,m.c)).join(""):`<p class="rpt-muted">${h("None")}</p>`}</div>

        <h4 class="rpt-section-title">${l(h("Highest-scored posts"))}</h4>
        ${P(t.topByScore,m=>m.score,"score")}

        <h4 class="rpt-section-title">${l(h("Most-commented posts"))}</h4>
        ${P(t.topByComments,m=>m.comments,"comments")}

        ${t.rulesDetail&&t.rulesDetail.length?`
          <h4 class="rpt-section-title">${l(h("Rules"))}</h4>
          <ol class="rpt-linklist">${t.rulesDetail.map(m=>`<li><strong>${l(m.short_name)}</strong>${m.description?` — <span class="rpt-muted">${l(String(m.description).slice(0,180))}</span>`:""}</li>`).join("")}</ol>`:""}

        ${t.mods.length?`
          <h4 class="rpt-section-title">${l(h("Moderators"))}</h4>
          <div class="rpt-chips-v">${t.mods.map(m=>d(`u/${m}`,"")).join("")}</div>`:""}

        ${F}

        <p class="rpt-muted" style="margin-top:14px;font-size:11px">
          ${l(h("Live data from Reddit's public JSON, combined with posts currently loaded in your feed. Scroll for a bigger sample."))}
        </p>`,I=k(`${h("Subreddit analyzer dashboard")} — r/${n}`,B,{wide:!0});I.querySelector('[data-act="refresh"]')?.addEventListener("click",async()=>{I.remove(),await this.open({force:!0})})},run(){this.open()}};function U(a,n={}){const e=n.h||120,o=1,s=a.length||1,r=(100-o*(s-1))/s,i=Math.max(1,...a),d=n.unit||"",c=n.labels||a.map((g,y)=>String(y)),p=a.map((g,y)=>{const $=g/i*(e-18),M=y*(r+o),_=e-14-$;return`<rect class="rpt-bar-rect" x="${M.toFixed(2)}" y="${_.toFixed(2)}" width="${r.toFixed(2)}" height="${$.toFixed(2)}" rx="0.6"><title>${l(c[y])} — ${g} ${l(d)}</title></rect>
        <text class="rpt-bar-lbl" x="${(M+r/2).toFixed(2)}" y="${e-3}" text-anchor="middle">${l(String(c[y]).slice(0,3))}</text>`}).join("");return`<svg class="rpt-svg-chart" viewBox="0 0 100 ${e}" preserveAspectRatio="none" role="img" aria-label="${l(n.ariaLabel||"chart")}">${p}</svg>`}u.modules.flairTools={id:"flairTools",name:"Flair tools",desc:"Filter, count, favorite or hide flairs on the current subreddit.",KEY:"rpt_v2_flairs",async open(){const a=q(),n={};a.forEach(r=>{r.flair&&(n[r.flair]=(n[r.flair]||0)+1)});const t=await b.get(this.KEY,{fav:{},hide:{}}),e=Object.entries(n).sort((r,i)=>i[1]-r[1]).map(([r,i])=>`
        <tr><td>${l(r)}</td><td>${i}</td>
          <td><label><input type="checkbox" data-fav="${l(r)}" ${t.fav[r]?"checked":""}> ★</label></td>
          <td><label><input type="checkbox" data-hide="${l(r)}" ${t.hide[r]?"checked":""}> Hide</label></td>
          <td><button class="rpt-mini" data-only="${l(r)}">Only this</button></td>
        </tr>`).join(""),o=e?`<table class="rpt-v2-table"><thead><tr><th>Flair</th><th>#</th><th>Fav</th><th>Hide</th><th></th></tr></thead><tbody>${e}</tbody></table>`:'<p class="rpt-muted">No flairs detected on loaded posts.</p>',s=k("Flair tools",o);s.querySelectorAll("[data-fav],[data-hide]").forEach(r=>r.onchange=async()=>{await b.patch(this.KEY,{fav:{},hide:{}},i=>(r.dataset.fav&&(i.fav[r.dataset.fav]=r.checked),r.dataset.hide&&(i.hide[r.dataset.hide]=r.checked),i)),this.apply()}),s.querySelectorAll("[data-only]").forEach(r=>r.onclick=()=>{const i=r.dataset.only;q().forEach(d=>{d.el.style.display=d.flair===i?"":"none"}),f(`Showing only: ${i}`),s.remove()})},async apply(){const a=await b.get(this.KEY,{fav:{},hide:{}});q().forEach(n=>{n.flair&&a.hide[n.flair]?n.el.style.display="none":n.el.style.display==="none"&&(n.el.style.display="")})},run(){this.open()}},u.modules.calendar={id:"calendar",name:"Subreddit activity calendar",desc:"Heatmap of loaded posts by day-of-week and hour.",async open(){const a=await R(C(),"new"),n=Array.from({length:7},()=>Array(24).fill(0));a.forEach(s=>{if(!s.created)return;const r=new Date(s.created);isNaN(r)||n[r.getDay()][r.getHours()]++});const t=Math.max(1,...n.flat()),e=["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],o=`<p class="rpt-muted">${l(h("Darker = more posts. Live sample from Reddit's newest 100 posts."))} (${a.length})</p>
        <table class="rpt-v2-cal"><thead><tr><th></th>${Array.from({length:24},(s,r)=>`<th>${r}</th>`).join("")}</tr></thead>
        <tbody>${e.map((s,r)=>`<tr><th>${s}</th>${n[r].map(i=>`<td style="background:rgba(255,69,0,${i/t})" title="${i} posts">${i||""}</td>`).join("")}</tr>`).join("")}</tbody></table>`;k("Activity calendar",o,{wide:!0})},run(){this.open()}},u.modules.topicTracker={id:"topicTracker",name:"Topic tracker",desc:"Follow keywords; count mentions across visited pages.",KEY:"rpt_v2_topics",async open(){await b.get(this.KEY,{topics:[]});const n=k("Topic tracker",`
        <div class="rpt-btnrow">
          <input id="rpt-tt-new" placeholder="Add keyword (e.g. linux)" style="flex:1">
          <button class="rpt-v2-primary" data-act="add">Add</button>
          <button class="rpt-v2-primary" data-act="scan">Scan this page</button>
        </div>
        <div id="rpt-tt-list"></div>`),t=async()=>{const e=await b.get(this.KEY,{topics:[]});n.querySelector("#rpt-tt-list").innerHTML=e.topics.length?e.topics.map(o=>`
          <div class="rpt-tt-row" data-t="${l(o.name)}">
            <strong>${l(o.name)}</strong>
            <span class="rpt-muted">${o.mentions} mentions · ${o.pages} pages</span>
            <button class="rpt-mini" data-act="del">🗑</button>
          </div>`).join(""):'<p class="rpt-muted">No topics tracked.</p>',n.querySelectorAll('[data-act="del"]').forEach(o=>o.onclick=async()=>{const s=o.closest("[data-t]").dataset.t;await b.patch(this.KEY,{topics:[]},r=>(r.topics=r.topics.filter(i=>i.name!==s),r)),t()})};n.querySelector('[data-act="add"]').onclick=async()=>{const e=n.querySelector("#rpt-tt-new").value.trim().toLowerCase();e&&(await b.patch(this.KEY,{topics:[]},o=>(o.topics.find(s=>s.name===e)||o.topics.push({name:e,mentions:0,pages:0}),o)),t())},n.querySelector('[data-act="scan"]').onclick=async()=>{const e=document.body.innerText.toLowerCase();await b.patch(this.KEY,{topics:[]},o=>(o.topics.forEach(s=>{const r=(e.match(new RegExp(`\\b${s.name.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}\\b`,"g"))||[]).length;r&&(s.mentions+=r,s.pages+=1)}),o)),f("Scanned"),t()},t()},run(){this.open()}},u.modules.repostDetector={id:"repostDetector",name:"Repost detector",desc:"Find posts with same URL or very similar titles on this page.",async open(){const a=C(),n=a?await R(a,"hot"):q(),t=d=>d.toLowerCase().replace(/[^a-z0-9 ]/g,"").split(/\s+/).filter(Boolean),e=(d,c)=>{const p=new Set(d),g=new Set(c),y=[...p].filter(M=>g.has(M)).length,$=new Set([...p,...g]).size;return $?y/$:0},o=[];for(let d=0;d<n.length;d++)for(let c=d+1;c<n.length;c++){const p=n[d],g=n[c],y=p.permalink&&p.permalink===g.permalink,$=e(t(p.title),t(g.title));(y||$>=.6)&&o.push({p,q:g,sim:y?1:$})}let s="";const r=window.RPT_API?.currentPostId?.();if(r)try{const d=await window.RPT_API.duplicates(r);d.length&&(s=`<h4 class="rpt-section-title">${l(h("Reddit-known duplicates of this post"))}</h4>
              <ul class="rpt-v2-linklist">${d.slice(0,20).map(c=>`<li><a href="${l(c.permalink)}" target="_blank" rel="noopener">${l(c.title)}</a>
                 <span class="rpt-muted"> — r/${l(c.subreddit)} · ▲${c.score} · ${c.comments}c</span></li>`).join("")}</ul>`)}catch{}const i=(s||"")+(o.length?o.map(({p:d,q:c,sim:p})=>`
        <div class="rpt-v2-dup">
          <div><span class="rpt-tag">${Math.round(p*100)}% match</span></div>
          <div><a href="${l(d.permalink)}" target="_blank" rel="noopener">${l(d.title)}</a> — ▲${d.score} · ${d.comments}c</div>
          <div><a href="${l(c.permalink)}" target="_blank" rel="noopener">${l(c.title)}</a> — ▲${c.score} · ${c.comments}c</div>
        </div>`).join(""):`<p class="rpt-muted">${l(h("No possible reposts detected among loaded posts."))}</p>`);k("Repost detector",i,{wide:!0})},run(){this.open()}},u.modules.sidebarCleaner={id:"sidebarCleaner",name:"Subreddit sidebar cleaner",desc:"Hide or collapse noisy sidebar sections; saved per subreddit.",KEY:"rpt_v2_sidebar",async open(){const a=C();if(!a)return f("Open a subreddit page");const n=document.querySelectorAll('aside .side, aside > *, [data-testid="right-rail"] > *'),t=(await b.get(this.KEY,{}))[a]||{hide:{}},e=n.length?[...n].map((s,r)=>{const i=(s.textContent||"").slice(0,60).trim()||`Section ${r+1}`;return`<label><input type="checkbox" data-sec="${r}" ${t.hide[r]?"checked":""}> Hide: ${l(i)}…</label>`}).join(""):'<p class="rpt-muted">No sidebar detected.</p>';k(`Sidebar cleaner — r/${a}`,e).querySelectorAll("[data-sec]").forEach(s=>s.onchange=async()=>{t.hide[s.dataset.sec]=s.checked,await b.patch(this.KEY,{},r=>(r[a]=t,r)),this.apply()}),this.apply()},async apply(){const a=C();if(!a)return;const n=(await b.get(this.KEY,{}))[a]||{hide:{}};document.querySelectorAll('aside .side, aside > *, [data-testid="right-rail"] > *').forEach((e,o)=>{e.style.display=n.hide[o]?"none":""})},run(){this.open()}},u.modules.wikiNav={id:"wikiNav",name:"Wiki navigator",desc:"Table of contents + search for wiki pages.",open(){if(!/\/wiki\//.test(location.pathname))return f("Open a wiki page");const a=document.querySelectorAll(".wiki-page-content h1, .wiki-page-content h2, .wiki-page-content h3, main h1, main h2, main h3"),n=`
        <input id="rpt-wk-q" placeholder="Search headings…" style="width:100%;padding:8px">
        <ul class="rpt-wk-toc">${[...a].map(e=>`<li data-lvl="${e.tagName[1]}"><a href="#${l(e.id||"")}" data-jump="${[...a].indexOf(e)}">${l(e.textContent.trim())}</a></li>`).join("")}</ul>
        <button class="rpt-v2-primary" data-act="export">Export wiki page as Markdown</button>`,t=k("Wiki navigator",n,{wide:!0});t.querySelector("#rpt-wk-q").oninput=e=>{const o=e.target.value.toLowerCase();t.querySelectorAll(".rpt-wk-toc li").forEach(s=>s.style.display=s.textContent.toLowerCase().includes(o)?"":"none")},t.querySelectorAll("[data-jump]").forEach(e=>e.onclick=o=>{o.preventDefault(),a[+e.dataset.jump].scrollIntoView({behavior:"smooth",block:"start"}),t.remove()}),t.querySelector('[data-act="export"]').onclick=()=>{const e=[...a].map(o=>`${"#".repeat(+o.tagName[1])} ${o.textContent.trim()}`).join(`
`);j(`wiki-${Date.now()}.md`,"text/markdown",e)}},run(){this.open()}},u.modules.resourceCollector={id:"resourceCollector",name:"Resource collector",desc:"Gather links from post/comments and categorize them.",open(){const a=[...document.querySelectorAll("main a[href^='http']")].map(s=>({href:s.href,text:s.textContent.trim().slice(0,80)})),n=s=>/github\.com/.test(s)?"GitHub":/(youtube|youtu\.be|vimeo)/.test(s)?"Videos":/(docs?\.|documentation)/.test(s)?"Documentation":/(tutorial|guide|howto)/.test(s)?"Tutorials":"Websites",t={};a.forEach(s=>{const r=n(s.href);(t[r]=t[r]||[]).push(s)});const e=Object.entries(t).map(([s,r])=>`
        <h4>${l(s)} (${r.length})</h4>
        <ul class="rpt-v2-linklist">${r.map(i=>`<li><a href="${l(i.href)}" target="_blank" rel="noopener">${l(i.text||i.href)}</a></li>`).join("")}</ul>`).join("")||'<p class="rpt-muted">No external links found.</p>',o=k("Resource collector",`${e}<button class="rpt-v2-primary" data-act="export">Export as Markdown</button>`,{wide:!0});o.querySelector('[data-act="export"]').onclick=()=>{const s=Object.entries(t).map(([r,i])=>`## ${r}
`+i.map(d=>`- [${d.text||d.href}](${d.href})`).join(`
`)).join(`

`);j(`resources-${Date.now()}.md`,"text/markdown",s)}},run(){this.open()}},u.modules.subGroups={id:"subGroups",name:"Subreddit groups",desc:"Group your favorite subreddits into named collections.",KEY:"rpt_v2_subgroups",async open(){await b.get(this.KEY,{groups:[]});const n=k("Subreddit groups",`
        <div class="rpt-btnrow">
          <input id="rpt-sg-name" placeholder="Group name" style="flex:1">
          <button class="rpt-v2-primary" data-act="new">Create group</button>
          <button class="rpt-v2-primary" data-act="export">Export JSON</button>
        </div>
        <div id="rpt-sg-list"></div>`),t=async()=>{const e=await b.get(this.KEY,{groups:[]});n.querySelector("#rpt-sg-list").innerHTML=e.groups.map((o,s)=>`
          <div class="rpt-sg-item" data-gi="${s}">
            <div class="rpt-sg-head">
              <strong>${l(o.name)}</strong>
              <button class="rpt-mini" data-act="add">＋ Add current sub</button>
              <button class="rpt-mini" data-act="rename">Rename</button>
              <button class="rpt-mini" data-act="del">🗑</button>
            </div>
            <textarea placeholder="Notes">${l(o.notes||"")}</textarea>
            <div>${o.subs.map(r=>`<a class="rpt-chip" href="/r/${l(r)}">r/${l(r)} ✕</a>`).join("")||'<span class="rpt-muted">No subs yet</span>'}</div>
          </div>`).join("")||'<p class="rpt-muted">No groups yet.</p>',n.querySelectorAll(".rpt-sg-item").forEach(o=>{const s=+o.dataset.gi;o.querySelector('[data-act="add"]').onclick=async()=>{const r=C();if(!r)return f("Open a subreddit");await b.patch(this.KEY,{groups:[]},i=>(i.groups[s].subs.includes(r)||i.groups[s].subs.push(r),i)),t()},o.querySelector('[data-act="rename"]').onclick=async()=>{const r=prompt("New name:");r&&(await b.patch(this.KEY,{groups:[]},i=>(i.groups[s].name=r,i)),t())},o.querySelector('[data-act="del"]').onclick=async()=>{confirm("Delete group?")&&(await b.patch(this.KEY,{groups:[]},r=>(r.groups.splice(s,1),r)),t())},o.querySelector("textarea").onchange=async r=>{await b.patch(this.KEY,{groups:[]},i=>(i.groups[s].notes=r.target.value,i))},o.querySelectorAll(".rpt-chip").forEach((r,i)=>r.onclick=async d=>{d.offsetX<r.offsetWidth-16||(d.preventDefault(),await b.patch(this.KEY,{groups:[]},c=>(c.groups[s].subs.splice(i,1),c)),t())})})};n.querySelector('[data-act="new"]').onclick=async()=>{const e=n.querySelector("#rpt-sg-name").value.trim();e&&(await b.patch(this.KEY,{groups:[]},o=>(o.groups.push({name:e,subs:[],notes:""}),o)),n.querySelector("#rpt-sg-name").value="",t())},n.querySelector('[data-act="export"]').onclick=async()=>{j(`rpt-subgroups-${Date.now()}.json`,"application/json",JSON.stringify(await b.get(this.KEY,{groups:[]}),null,2))},t()},run(){this.open()}},u.modules.subHealth={id:"subHealth",name:"Subreddit health monitor",desc:"Compute activity, engagement and spam signals locally.",async open(){const a=C(),n=a?await R(a,"new"):q();let t=0,e=0,o=0,s=0;try{const S=a?await window.RPT_API?.about?.(a):null;var r=S?.subscribers??null,i=S?.active_user_count??S?.accounts_active??null}catch{}e=n.filter(S=>S.locked).length;const d=window.RPT_API?.currentPostId?.();if(d)try{const S=await window.RPT_API.comments(d,{limit:500});S&&(t=S.comments.filter(P=>P.removed).length,o=S.comments.filter(P=>P.distinguished==="moderator").length,s=S.comments.filter(P=>P.controversial).length)}catch{}const c=n.filter(S=>S.comments>0).length,p=n.filter(S=>S.comments===0).length,g=t||document.querySelectorAll('.deleted, [deleted], shreddit-comment[author="[deleted]"]').length,y=n.filter(S=>/free|discount|check.*bio|onlyfans/i.test(S.title)).length,$=Math.max(0,Math.min(100,Math.round(c/Math.max(1,n.length)*100-y*5-p*.5))),M=S=>S==null?"—":S>=1e6?(S/1e6).toFixed(1)+"M":S>=1e3?(S/1e3).toFixed(1)+"k":String(S),_=`
        <div class="rpt-v2-health"><div class="rpt-v2-health-num" style="color:${$>60?"var(--brand-2)":$>30?"#f59e0b":"#ef4444"}">${$}</div><div>Health score</div></div>
        <div class="rpt-v2-cmp-grid">
          <div><small>${l(h("Members"))}</small><strong>${M(r)}</strong></div>
          <div><small>${l(h("Online now"))}</small><strong>${M(i)}</strong></div>
          <div><small>Posts sampled</small><strong>${n.length}</strong></div>
          <div><small>With comments</small><strong>${c}</strong></div>
          <div><small>Dead posts</small><strong>${p}</strong></div>
          <div><small>Deleted comments</small><strong>${g}</strong></div>
          <div><small>${l(h("Locked posts"))}</small><strong>${e}</strong></div>
          <div><small>${l(h("Mod comments"))}</small><strong>${o}</strong></div>
          <div><small>${l(h("Controversial"))}</small><strong>${s}</strong></div>
          <div><small>Spam hints</small><strong>${y}</strong></div>
          <div><small>Avg score</small><strong>${n.length?Math.round(n.reduce((S,P)=>S+P.score,0)/n.length):0}</strong></div>
        </div>`;k("Subreddit health",_)},run(){this.open()}},u.modules.qualityFilter={id:"qualityFilter",name:"Post quality filter",desc:"Hide low-effort posts; show only high-engagement ones.",KEY:"rpt_v2_quality",async open(){const a=await b.get(this.KEY,{minScore:0,minComments:0,minTitle:0,hideShort:!1}),n=`
        <label>Min score <input type="number" data-k="minScore" value="${a.minScore}"></label>
        <label>Min comments <input type="number" data-k="minComments" value="${a.minComments}"></label>
        <label>Min title length <input type="number" data-k="minTitle" value="${a.minTitle}"></label>
        <label><input type="checkbox" data-k="hideShort" ${a.hideShort?"checked":""}> Hide short titles (&lt;20 chars)</label>
        <button class="rpt-v2-primary" data-act="apply">Apply</button>`,t=k("Post quality filter",n);t.querySelector('[data-act="apply"]').onclick=async()=>{const e={};t.querySelectorAll("[data-k]").forEach(o=>e[o.dataset.k]=o.type==="checkbox"?o.checked:+o.value||0),await b.set(this.KEY,e),this.apply(),f("Applied"),t.remove()}},async apply(){const a=await b.get(this.KEY,{minScore:0,minComments:0,minTitle:0,hideShort:!1});q().forEach(t=>{const e=t.score<a.minScore||t.comments<a.minComments||t.title.length<a.minTitle||a.hideShort&&t.title.length<20;t.el&&(t.el.style.display=e?"none":"")})},run(){this.open()}},u.modules.timeline={id:"timeline",name:"Subreddit timeline",desc:"Chronological view of loaded posts.",async open(){const a=C(),t=(a?await R(a,"new"):q()).filter(o=>o.created).sort((o,s)=>new Date(o.created)-new Date(s.created)),e=t.length?`<ol class="rpt-v2-timeline">${t.map(o=>`
        <li><time>${new Date(o.created).toLocaleString()}</time>
          <a href="${l(o.permalink)}" target="_blank" rel="noopener">${l(o.title)}</a>
          <span class="rpt-muted">▲${o.score} · ${o.comments}c</span></li>`).join("")}</ol>`:`<p class="rpt-muted">${l(h("No timestamped posts detected."))}</p>`;k("Subreddit timeline",e,{wide:!0})},run(){this.open()}},u.modules.searchEnhancer={id:"searchEnhancer",name:"Search enhancer",desc:"Build advanced Reddit search URLs with filters.",open(){const a=C(),n=`
        <label>Keywords <input id="rs-q" placeholder="docker best practices"></label>
        <label>Author <input id="rs-a" placeholder="username"></label>
        <label>Flair <input id="rs-f"></label>
        <label>Min score <input id="rs-s" type="number"></label>
        <label>Post type
          <select id="rs-t"><option value="">Any</option><option>self</option><option>image</option><option>link</option><option>video</option></select>
        </label>
        <label>Sort
          <select id="rs-o"><option>relevance</option><option>new</option><option>top</option><option>comments</option></select>
        </label>
        <label>Time <select id="rs-tt"><option>all</option><option>year</option><option>month</option><option>week</option><option>day</option></select></label>
        <label>Restrict to r/${l(a||"…")} <input id="rs-r" type="checkbox" ${a?"checked":""}></label>
        <button class="rpt-v2-primary" data-act="go">Search</button>`,t=k("Search enhancer",n);t.querySelector('[data-act="go"]').onclick=()=>{const e=[t.querySelector("#rs-q").value],o=t.querySelector("#rs-a").value;o&&e.push(`author:${o}`);const s=t.querySelector("#rs-f").value;s&&e.push(`flair:"${s}"`);const r=t.querySelector("#rs-s").value;r&&e.push(`score:>${r}`);const i=t.querySelector("#rs-t").value;i&&e.push(`self:${i==="self"}`);const d=encodeURIComponent(e.filter(Boolean).join(" ")),c=t.querySelector("#rs-r").checked&&a?`/r/${a}`:"",p=`https://www.reddit.com${c}/search/?q=${d}&sort=${t.querySelector("#rs-o").value}&t=${t.querySelector("#rs-tt").value}${c?"&restrict_sr=1":""}`;window.open(p,"_blank"),t.remove()}},run(){this.open()}},u.modules.trendTracker={id:"trendTracker",name:"Trend tracker",desc:"Compares latest snapshot with previous to spot rising/falling keywords.",KEY:"rpt_v2_trends",async open(){const a=C();if(!a)return f("Open a subreddit");const n=await u.modules.communityCompare.snapshotLive(),t=await b.get(this.KEY,{}),e=t[a];let o="";if(!e)o='<p class="rpt-muted">No previous data. Saving baseline now — come back later to see trends.</p>';else{const s=Object.fromEntries(e.topKeywords.map(i=>[i.w,i.c])),r=n.topKeywords.map(i=>({w:i.w,delta:i.c-(s[i.w]||0)})).sort((i,d)=>d.delta-i.delta);o=`
          <h4>Rising</h4>${r.filter(i=>i.delta>0).slice(0,10).map(i=>`<span class="rpt-chip">${l(i.w)} +${i.delta}</span>`).join("")||"<p class='rpt-muted'>None</p>"}
          <h4>Falling</h4>${r.filter(i=>i.delta<0).slice(-10).map(i=>`<span class="rpt-chip">${l(i.w)} ${i.delta}</span>`).join("")||"<p class='rpt-muted'>None</p>"}`}t[a]=n,await b.set(this.KEY,t),k(`Trends — r/${a}`,o)},run(){this.open()}},u.modules.contentExporter={id:"contentExporter",name:"Subreddit content exporter",desc:"Export loaded posts + flairs + rules as JSON/MD.",async open(){const a=C(),t=(a?await R(a,"hot"):q()).map(d=>({title:d.title,author:d.author,score:d.score,comments:d.comments,permalink:d.permalink,flair:d.flair,type:d.type,domain:d.domain,created:d.created,nsfw:d.nsfw}));let e=[];try{const d=a?await window.RPT_API?.rules?.(a):null;e=Array.isArray(d?.rules)?d.rules.map(c=>c.short_name||c.violation_reason||""):[]}catch{}const o=e.length?e:[...document.querySelectorAll('[data-testid*="rule"], .rule')].map(d=>d.innerText.trim()),s=[...new Set(t.map(d=>d.flair).filter(Boolean))],r=`<p>${l(h("Ready to export"))} r/${l(a||"current")} — ${t.length} posts, ${s.length} flairs, ${o.length} rules.</p>
        <div class="rpt-btnrow">
          <button class="rpt-v2-primary" data-f="json">Export JSON</button>
          <button class="rpt-v2-primary" data-f="md">Export Markdown</button>
          <button class="rpt-v2-primary" data-f="html">Export HTML</button>
        </div>`,i=k("Subreddit content exporter",r);i.querySelectorAll("[data-f]").forEach(d=>d.onclick=()=>{const c={sub:a,exportedAt:new Date().toISOString(),posts:t,flairs:s,rules:o};d.dataset.f==="json"?j(`r-${a}-${Date.now()}.json`,"application/json",JSON.stringify(c,null,2)):d.dataset.f==="md"?j(`r-${a}-${Date.now()}.md`,"text/markdown",`# r/${a}

## Rules
${o.map((p,g)=>`${g+1}. ${p}`).join(`
`)}

## Posts
${t.map(p=>`- [${p.title}](${p.permalink}) — u/${p.author}, ▲${p.score}, ${p.comments}c`).join(`
`)}`):j(`r-${a}-${Date.now()}.html`,"text/html",`<h1>r/${l(a)}</h1>`+t.map(p=>`<div><a href="${l(p.permalink)}">${l(p.title)}</a></div>`).join("")),i.remove()})},run(){this.open()}},u.modules.feedDedup={id:"feedDedup",name:"Feed deduplicator",desc:"Hide duplicate posts (same URL or near-identical title).",async apply(){const a=q(),n=new Map;let t=0;a.forEach(e=>{const o=e.permalink||e.title.toLowerCase().replace(/\W+/g," ").trim();if(n.has(o)){const s=n.get(o);s.score>=e.score?(e.el.style.display="none",t++):(s.el.style.display="none",n.set(o,e),t++)}else n.set(o,e)}),f(`Hid ${t} duplicates`)},run(){this.apply()}},u.modules.ageSort={id:"ageSort",name:"Post age & engagement sort",desc:"Reorder posts on-page by age / engagement bucket.",open(){const n=k("Post age sorting",`<div class="rpt-btnrow">
        <button class="rpt-v2-primary" data-s="new">Newest</button>
        <button class="rpt-v2-primary" data-s="old">Oldest</button>
        <button class="rpt-v2-primary" data-s="fresh">Fresh discussions</button>
        <button class="rpt-v2-primary" data-s="active">Old but active</button>
        <button class="rpt-v2-primary" data-s="engage">Highest engagement</button>
      </div>`);n.querySelectorAll("[data-s]").forEach(t=>t.onclick=async()=>{const e=C();let o=[];if(e)try{o=await window.RPT_API.posts(e,"new",{limit:100})}catch{}const s=new Map(o.map(p=>[String(p.permalink).replace(/^https?:\/\/[^/]+/,""),p])),r=q().filter(p=>p.el&&p.el.parentElement).map(p=>{const g=s.get(String(p.permalink).replace(/^https?:\/\/[^/]+/,""));return g?{...p,created:g.created||p.created,score:g.score||p.score,comments:g.comments||p.comments}:p}),i=r[0]?.el.parentElement;if(!i)return f("No posts");const d=Date.now(),c=p=>{const g=p.created?(d-new Date(p.created))/864e5:999;switch(t.dataset.s){case"new":return-g;case"old":return g;case"fresh":return g<1?p.comments:-1;case"active":return g>30&&p.comments>5?p.comments:-1;case"engage":return p.comments+p.score}};r.sort((p,g)=>c(g)-c(p)).forEach(p=>i.appendChild(p.el)),f(`Sorted: ${t.dataset.s}`),n.remove()})},run(){this.open()}},u.modules.linksManager={id:"linksManager",name:"Open links manager",desc:"Collect all links; open selected, copy, export, group by domain.",open(){const a=[...document.querySelectorAll("main a[href^='http']")].map(s=>({href:s.href,text:s.textContent.trim().slice(0,100)})),n={};a.forEach(s=>{const r=new URL(s.href).hostname;(n[r]=n[r]||[]).push(s)});const t=`<div class="rpt-btnrow">
          <button class="rpt-v2-primary" data-act="allsel">Select all</button>
          <button class="rpt-v2-primary" data-act="open">Open selected</button>
          <button class="rpt-v2-primary" data-act="copy">Copy selected</button>
          <button class="rpt-v2-primary" data-act="export">Export CSV</button>
        </div>
        ${Object.entries(n).map(([s,r])=>`<h4>${l(s)} (${r.length})</h4>
          <ul class="rpt-v2-linklist">${r.map((i,d)=>`<li><label><input type="checkbox" data-i="${s}::${d}"> <a href="${l(i.href)}" target="_blank">${l(i.text||i.href)}</a></label></li>`).join("")}</ul>`).join("")||'<p class="rpt-muted">No links found.</p>'}`,e=k("Open links manager",t,{wide:!0}),o=()=>[...e.querySelectorAll('input[type="checkbox"]:checked')].map(s=>{const[r,i]=s.dataset.i.split("::");return n[r][+i].href});e.querySelector('[data-act="allsel"]').onclick=()=>e.querySelectorAll("input").forEach(s=>s.checked=!0),e.querySelector('[data-act="open"]').onclick=()=>o().forEach(s=>window.open(s,"_blank")),e.querySelector('[data-act="copy"]').onclick=()=>{navigator.clipboard.writeText(o().join(`
`)),f("Copied")},e.querySelector('[data-act="export"]').onclick=()=>j(`links-${Date.now()}.csv`,"text/csv",`domain,url,text
`+a.map(s=>`"${new URL(s.href).hostname}","${s.href}","${s.text.replace(/"/g,'""')}"`).join(`
`))},run(){this.open()}},u.modules.copyTools={id:"copyTools",name:"Copy tools",desc:"Quick copy: title, url, text, markdown, thread structure.",open(){x.state.post;const a=document.querySelector("h1")?.textContent?.trim()||document.title,n=location.href,t=document.querySelector("main")?.innerText?.slice(0,4e3)||"",e=()=>{const i=x.state.tree||x.features.commentTree.parse(),d=(c,p=0)=>`${"  ".repeat(p)}- ${c.author}: ${(c.body||"").split(`
`)[0].slice(0,80)}
`+(c.children||[]).map(g=>d(g,p+1)).join("");return i.map(c=>d(c)).join("")},o=[["Title",a],["URL",n],["Title + URL",`${a}
${n}`],["Page text",t],["Markdown link",`[${a}](${n})`],["Thread structure",e()]],s=`<div class="rpt-btnrow" style="flex-wrap:wrap">${o.map(([i,d],c)=>`<button class="rpt-v2-primary" data-i="${c}">${l(i)}</button>`).join("")}</div>`;k("Copy tools",s).querySelectorAll("[data-i]").forEach(i=>i.onclick=()=>{navigator.clipboard.writeText(o[+i.dataset.i][1]),f("Copied: "+o[+i.dataset.i][0])})},run(){this.open()}},u.modules.explainLink={id:"explainLink",name:"Explain this link",desc:"Metadata + category for hovered links (no AI, no fetch).",enabled:!1,_tip:null,enable(){this.enabled||(this.enabled=!0,document.addEventListener("mouseover",a=>{const n=a.target.closest?.("a[href^='http']");if(n)try{const t=new URL(n.href),e=(t.pathname.match(/\.[a-z0-9]{2,4}$/i)||[""])[0].slice(1),o=/youtube|youtu\.be|vimeo/.test(t.hostname)?"Video":/github\.com|gitlab\.com/.test(t.hostname)?"Code":/reddit\.com/.test(t.hostname)?"Reddit (internal)":/(png|jpg|jpeg|gif|webp)$/i.test(e)?"Image":/(pdf|doc|docx)$/i.test(e)?"Document":"Web page";this._tip||(this._tip=document.createElement("div"),this._tip.className="rpt-v2-linktip",document.body.appendChild(this._tip)),this._tip.innerHTML=`<strong>${l(o)}</strong><div>${l(t.hostname)}</div>${e?`<div>.${l(e)}</div>`:""}`;const s=n.getBoundingClientRect();this._tip.style.left=s.left+"px",this._tip.style.top=s.bottom+4+"px",this._tip.style.display="block"}catch{}},!0),document.addEventListener("mouseout",()=>{this._tip&&(this._tip.style.display="none")},!0))},run(){this.enable(),f("Hover links to see details")}},u.modules.savedManager={id:"savedManager",name:"Saved content manager",desc:"Alias to the bookmarks system focused on your saved items.",run(){u.modules.bookmarks.open()}},u.modules.exportLibrary={id:"exportLibrary",name:"Export library",desc:"Central export of everything RPT stores locally.",async open(){const a=await new Promise(o=>chrome.storage.local.get(null,o)),n=Object.fromEntries(Object.entries(a).filter(([o])=>o.startsWith("rpt"))),t=`<p>Bundles ${Object.keys(n).length} keys of local RPT data (~${(JSON.stringify(n).length/1024).toFixed(1)} KB).</p>
        <div class="rpt-btnrow">
          <button class="rpt-v2-primary" data-act="dl">Download JSON</button>
          <button class="rpt-v2-primary" data-act="wipe">Wipe all local RPT data</button>
        </div>`,e=k("Export library",t);e.querySelector('[data-act="dl"]').onclick=()=>j(`rpt-library-${Date.now()}.json`,"application/json",JSON.stringify(n,null,2)),e.querySelector('[data-act="wipe"]').onclick=()=>{confirm("Wipe ALL local RPT data? This cannot be undone.")&&chrome.storage.local.remove(Object.keys(n),()=>{f("Wiped"),e.remove()})}},run(){this.open()}},u.modules.achievements={id:"achievements",name:"Achievements",desc:"Personal milestones based on your local usage.",KEY:"rpt_v2_ach",async tick(a,n=1){await b.patch(this.KEY,{},t=>(t[a]=(t[a]||0)+n,t))},async open(){const a=await b.get(this.KEY,{}),t=[["threadsRead","Threads read",100],["commentsSaved","Comments saved",25],["subsVisited","Subs visited",50],["exports","Exports made",10],["bookmarks","Bookmarks added",50]].map(([e,o,s])=>{const r=a[e]||0,i=Math.min(100,r/s*100);return`<div class="rpt-v2-ach"><div><strong>${o}</strong><span class="rpt-muted"> ${r}/${s}</span></div><div class="rpt-v2-bar"><i style="width:${i}%"></i></div></div>`}).join("");k("Achievements",t)},run(){this.open()}},u.modules.oldGold={id:"oldGold",name:"Old gold finder",desc:"Highlight old but highly upvoted / commented posts on this page.",async apply(){const a=q(),n=C();let t=[];if(n)try{t=await window.RPT_API?.posts(n,"top",{t:"all",limit:100})}catch{}const e=new Map(t.map(s=>[String(s.permalink).replace(/^https?:\/\/[^/]+/,""),s]));let o=0;a.forEach(s=>{const r=e.get(String(s.permalink).replace(/^https?:\/\/[^/]+/,"")),i=r?.created||s.created,d=r?.score||s.score,c=r?.comments||s.comments;if(!i)return;(Date.now()-new Date(i))/864e5>180&&(d>500||c>100)&&(s.el&&s.el.classList.add("rpt-oldgold"),o++)}),f(`Marked ${o} old-gold posts`)},run(){this.apply()}},u.modules.random={id:"random",name:"Random discovery",desc:"Jump to a random loaded post or saved bookmark.",async open(){const n=k("Random discovery",`<div class="rpt-btnrow">
        <button class="rpt-v2-primary" data-act="post">Random post on page</button>
        <button class="rpt-v2-primary" data-act="sub">Random popular subreddit</button>
        <button class="rpt-v2-primary" data-act="bm">Random bookmark</button>
      </div>`);n.querySelector('[data-act="post"]').onclick=()=>{const t=q();if(!t.length)return f("No posts");const e=t[Math.floor(Math.random()*t.length)];e.permalink?location.href=e.permalink:e.el.scrollIntoView({behavior:"smooth"})},n.querySelector('[data-act="sub"]').onclick=()=>{const t=["AskReddit","todayilearned","science","worldnews","explainlikeimfive","LifeProTips","dataisbeautiful","IAmA","pics","showerthoughts"];location.href="https://www.reddit.com/r/"+t[Math.floor(Math.random()*t.length)]},n.querySelector('[data-act="bm"]').onclick=async()=>{const t=await b.get("rpt_v2_bookmarks",{items:[]});if(!t.items.length)return f("No bookmarks");location.href=t.items[Math.floor(Math.random()*t.items.length)].url}},run(){this.open()}},u.modules.research={id:"research",name:"Research workspace",desc:"Collect posts/comments with notes into a named research bundle.",KEY:"rpt_v2_research",async open(){const a=await b.get(this.KEY,{active:"",bundles:{}}),n=`
        <div class="rpt-btnrow">
          <input id="rpt-rs-name" placeholder="Bundle name" value="${l(a.active)}" style="flex:1">
          <button class="rpt-v2-primary" data-act="setActive">Set active</button>
          <button class="rpt-v2-primary" data-act="addPost">Add current post</button>
          <button class="rpt-v2-primary" data-act="export">Export active</button>
        </div>
        <div id="rpt-rs-list"></div>`,t=k("Research workspace",n,{wide:!0}),e=async()=>{const o=await b.get(this.KEY,{active:"",bundles:{}});t.querySelector("#rpt-rs-list").innerHTML=Object.entries(o.bundles).map(([s,r])=>`
          <div class="rpt-sg-item">
            <div class="rpt-sg-head"><strong>${l(s)}</strong> <span class="rpt-muted">${r.length} items</span>
              ${s===o.active?'<span class="rpt-tag">active</span>':`<button class="rpt-mini" data-use="${l(s)}">Use</button>`}
              <button class="rpt-mini" data-del="${l(s)}">🗑</button>
            </div>
            <ul>${r.map(i=>`<li><a href="${l(i.url)}" target="_blank">${l(i.title)}</a> — <em>${l(i.note||"")}</em></li>`).join("")}</ul>
          </div>`).join("")||'<p class="rpt-muted">No bundles yet.</p>',t.querySelectorAll("[data-use]").forEach(s=>s.onclick=async()=>{await b.patch(this.KEY,{active:"",bundles:{}},r=>(r.active=s.dataset.use,r)),e()}),t.querySelectorAll("[data-del]").forEach(s=>s.onclick=async()=>{await b.patch(this.KEY,{active:"",bundles:{}},r=>(delete r.bundles[s.dataset.del],r.active===s.dataset.del&&(r.active=""),r)),e()})};t.querySelector('[data-act="setActive"]').onclick=async()=>{const o=t.querySelector("#rpt-rs-name").value.trim();o&&(await b.patch(this.KEY,{active:"",bundles:{}},s=>(s.bundles[o]||(s.bundles[o]=[]),s.active=o,s)),e())},t.querySelector('[data-act="addPost"]').onclick=async()=>{const o=prompt("Note (optional):")||"";await b.patch(this.KEY,{active:"",bundles:{}},s=>(s.active&&s.bundles[s.active].push({url:location.href,title:document.title,note:o,addedAt:Date.now()}),s)),f("Added"),e()},t.querySelector('[data-act="export"]').onclick=async()=>{const o=await b.get(this.KEY,{active:"",bundles:{}});if(!o.active)return f("Set an active bundle first");j(`research-${o.active}-${Date.now()}.md`,"text/markdown",`# ${o.active}

`+o.bundles[o.active].map(s=>`- [${s.title}](${s.url})
  > ${s.note||""}`).join(`

`))},e()},run(){this.open()}},u.modules.history={id:"history",name:"Local Reddit history",desc:"Local log of pages you visited on Reddit (search + open).",KEY:"rpt_v2_history",async record(){/reddit\.com/.test(location.hostname)&&await b.patch(this.KEY,{items:[]},a=>{const n=location.href;return a.items=a.items.filter(t=>t.url!==n),a.items.unshift({url:n,title:document.title,at:Date.now()}),a.items.length>500&&(a.items.length=500),a})},async open(){const a=await b.get(this.KEY,{items:[]}),t=k("Reddit history",`<input id="rpt-hi-q" placeholder="Search history…" style="width:100%;padding:8px">
        <ul id="rpt-hi-list" class="rpt-v2-linklist"></ul>`,{wide:!0}),e=(o="")=>{t.querySelector("#rpt-hi-list").innerHTML=a.items.filter(s=>!o||s.title.toLowerCase().includes(o)||s.url.toLowerCase().includes(o)).slice(0,200).map(s=>`<li><a href="${l(s.url)}">${l(s.title)}</a> <span class="rpt-muted">${new Date(s.at).toLocaleString()}</span></li>`).join("")};t.querySelector("#rpt-hi-q").oninput=o=>e(o.target.value.toLowerCase()),e()},run(){this.open()}},u.modules.followKeywords={id:"followKeywords",name:"Follow keywords",desc:"Highlight tracked topics in the current page and count mentions.",async run(){const a=await b.get("rpt_v2_topics",{topics:[]});if(!a.topics.length)return f("Add topics via Topic tracker first");const n=a.topics.map(o=>o.name),t=new RegExp(`\\b(${n.map(o=>o.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")).join("|")})\\b`,"gi");let e=0;document.querySelectorAll("main p, main li, main [slot='comment']").forEach(o=>{if(o.querySelector(".rpt-v2-mark"))return;const s=o.innerHTML.replace(t,r=>(e++,`<mark class="rpt-v2-mark">${r}</mark>`));s!==o.innerHTML&&(o.innerHTML=s)}),f(`Highlighted ${e} mentions of ${n.length} tracked keywords`)}},u.modules.mediaToggle={id:"mediaToggle",name:"Image / text / video toggle",desc:"Filter feed to a single content type at a time.",open(){const n=k("Media toggle",`<div class="rpt-btnrow">
        <button class="rpt-v2-primary" data-t="image">Only images</button>
        <button class="rpt-v2-primary" data-t="video">Only videos</button>
        <button class="rpt-v2-primary" data-t="text">Only text</button>
        <button class="rpt-v2-primary" data-t="link">Only links</button>
        <button class="rpt-v2-primary" data-t="">Show all</button>
      </div>`);n.querySelectorAll("[data-t]").forEach(t=>t.onclick=()=>{const e=t.dataset.t;q().forEach(o=>{o.el.style.display=!e||o.type===e?"":"none"}),f(e?`Only ${e}`:"All"),n.remove()})},run(){this.open()}},u.modules.devMode={id:"devMode",name:"Developer mode",desc:"Inspect the hovered element: Reddit IDs, timestamps, JSON.",enabled:!1,enable(){if(this.enabled)return;this.enabled=!0,document.body.classList.add("rpt-devmode");const a=document.createElement("div");a.className="rpt-v2-devtip",document.body.appendChild(a),document.addEventListener("mousemove",n=>{const t=n.target,e={tag:t.tagName?.toLowerCase(),id:t.id||void 0,thingid:t.getAttribute?.("thingid")||void 0,author:t.getAttribute?.("author")||void 0,created:t.getAttribute?.("created-timestamp")||void 0,score:t.getAttribute?.("score")||void 0};a.textContent=Object.entries(e).filter(([,o])=>o).map(([o,s])=>`${o}=${s}`).join("  "),a.style.left=n.clientX+12+"px",a.style.top=n.clientY+12+"px"})},disable(){this.enabled=!1,document.body.classList.remove("rpt-devmode"),document.querySelectorAll(".rpt-v2-devtip").forEach(a=>a.remove())},run(){this.enabled?(this.disable(),f("Dev mode off")):(this.enable(),f("Dev mode on — hover elements"))}};const Q=[["Community",["communityCompare","subAnalyzer","calendar","subHealth","timeline","trendTracker","subGroups","contentExporter"]],["Thread & comments",["miniMap","commentExport","userAnalytics","postAnalytics","copyTools","followKeywords"]],["Filtering & feed",["flairTools","qualityFilter","feedDedup","ageSort","mediaToggle","oldGold","sidebarCleaner"]],["Discovery & knowledge",["bookmarks","savedManager","research","topicTracker","random","history","achievements","wikiNav","resourceCollector"]],["Utilities",["searchEnhancer","linksManager","explainLink","exportLibrary","repostDetector","devMode"]]];u.HUB_KEY="rpt_v2_enabled",u.enabledDefaults=()=>Object.fromEntries(Object.keys(u.modules).map(a=>[a,!0])),u.getEnabled=async()=>({...u.enabledDefaults(),...await b.get(u.HUB_KEY,{})}),u.openHub=async()=>{const a=await u.getEnabled(),n=`
      <p class="rpt-muted">36 advanced features — all run locally. Click to launch, or toggle to disable individually.</p>
      <input id="rpt-hub-q" placeholder="${A("search_features")}" style="width:100%;padding:10px;margin-bottom:10px;background:var(--bg-2);border:1px solid var(--border);border-radius:8px;color:var(--fg)">
      ${Q.map(([e,o])=>`
        <h3 class="rpt-hub-cat">${l(e)}</h3>
        <div class="rpt-hub-grid">
          ${o.map(s=>{const r=u.modules[s];return r?`<div class="rpt-hub-card ${a[s]?"":"rpt-hub-off"}" data-id="${s}">
              <button class="rpt-hub-run" data-run="${s}">
                <strong>${l(h(r.name))}</strong>
                <span>${l(h(r.desc))}</span>
              </button>
              <label class="rpt-hub-toggle" title="${A("enable_disable")}">
                <input type="checkbox" data-tog="${s}" ${a[s]?"checked":""}>
              </label>
            </div>`:""}).join("")}
        </div>`).join("")}`,t=k(A("power_features"),n,{wide:!0});t.querySelectorAll("[data-run]").forEach(e=>e.onclick=async()=>{const o=e.dataset.run;if(!(await u.getEnabled())[o])return f(A("feature_disabled_turn_on"));try{t.remove(),u.modules[o].run?.()}catch(r){console.error(r),f(`${A("feature_error")}: ${r.message}`)}}),t.querySelectorAll("[data-tog]").forEach(e=>e.onclick=async o=>{o.stopPropagation(),await b.patch(u.HUB_KEY,{},s=>(s[e.dataset.tog]=e.checked,s)),e.closest(".rpt-hub-card").classList.toggle("rpt-hub-off",!e.checked)}),t.querySelector("#rpt-hub-q").oninput=e=>{const o=e.target.value.toLowerCase();t.querySelectorAll(".rpt-hub-card").forEach(s=>{s.style.display=s.textContent.toLowerCase().includes(o)?"":"none"})}};const H=async()=>{const a=await u.getEnabled();try{a.history&&u.modules.history.record()}catch{}try{a.userAnalytics&&u.modules.userAnalytics.enable()}catch{}try{a.postAnalytics&&u.modules.postAnalytics.enable()}catch{}try{a.explainLink&&u.modules.explainLink.enable()}catch{}try{a.flairTools&&u.modules.flairTools.apply()}catch{}try{a.sidebarCleaner&&u.modules.sidebarCleaner.apply()}catch{}try{a.qualityFilter&&u.modules.qualityFilter.apply()}catch{}try{a.achievements&&u.modules.achievements.tick("threadsRead")}catch{}};document.readyState==="loading"?document.addEventListener("DOMContentLoaded",H):setTimeout(H,200);let z=location.pathname;new MutationObserver(()=>{location.pathname!==z&&(z=location.pathname,setTimeout(H,400))}).observe(document.documentElement,{childList:!0,subtree:!0}),u.open=u.openHub,u.list=()=>Object.values(u.modules).map(a=>({id:a.id,name:a.name,desc:a.desc}));try{const a=x.features.cmdk?.commands;typeof a=="function"&&(x.features.cmdk.commands=function(){return a.call(this).concat({id:"v2-hub",label:`${A("power_features")} — ${A("hub")}`,run:()=>u.openHub()},...Object.values(u.modules).map(t=>({id:`v2-${t.id}`,label:`⚡ ${h(t.name)}`,run:()=>t.run()})))})}catch{}})();
