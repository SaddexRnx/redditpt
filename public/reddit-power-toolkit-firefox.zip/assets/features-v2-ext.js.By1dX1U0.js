(function(){if(!window.RPT||!window.RPT.v2)return;const $=window.RPT,t=$.v2,w=t._storage,y=t._modal,r=e=>$.utils.escapeHtml(String(e??"")),a=e=>window.RPT_I18N?.t(e)||e,o=e=>window.RPT_I18N?.text(e)||e,f=()=>{const e=location.pathname.match(/\/r\/([^\/]+)/i);return e?e[1].toLowerCase():null},h=e=>{const c=document.createElement("div");c.className="rpt-v2-toast",c.textContent=e,document.body.appendChild(c),setTimeout(()=>c.remove(),2600)};t._perf={runs:{},mounted:Date.now()},t.perSubKey="rpt_v2_per_sub",t.getPerSub=()=>w.get(t.perSubKey,{}),t.setPerSub=e=>w.set(t.perSubKey,e),t.isEnabledHere=async e=>{const c=f();if(!c)return!0;const n=(await t.getPerSub())[c];return n?n[e]!==!1:!0},Object.keys(t.modules).forEach(e=>{const c=t.modules[e],s=c.run;typeof s!="function"||c._wrapped||(c._wrapped=!0,c.run=async function(...n){if(!await t.isEnabledHere(e)){h(`"${c.name}" is disabled in r/${f()}`);return}const d=performance.now();try{const l=await s.apply(this,n),u=Math.round(performance.now()-d);return t._perf.runs[e]={at:Date.now(),ms:u,ok:!0},l}catch(l){throw t._perf.runs[e]={at:Date.now(),ms:Math.round(performance.now()-d),ok:!1,err:String(l?.message||l)},l}})}),t.modules.perfStatus={id:"perfStatus",name:"Performance & status",desc:a("perf_status_desc"),async open(){const e=await t.getEnabled(),c=await t.getPerSub(),s=f(),n=s&&c[s]||{},i=Object.values(t.modules).filter(m=>m.id!=="perfStatus").map(m=>{const b=t._perf.runs[m.id],g=e[m.id]!==!1,v=n[m.id]!==!1,k=g&&v,_=b?new Date(b.at).toLocaleTimeString():"—",x=b?`${b.ms} ms`:"—";return`<tr>
            <td>${b?b.ok?"●":"✕":"○"}</td>
            <td><strong>${r(o(m.name))}</strong><br><span class="rpt-muted">${r(o(m.desc))}</span></td>
            <td>${k?`<span class='rpt-badge-on'>${a("on")}</span>`:`<span class='rpt-badge-off'>${a("off")}</span>`}</td>
            <td>${_}</td>
            <td>${x}</td>
            <td><button class="rpt-mini-btn" data-fetch="${r(m.id)}" title="${r(o("Fetch latest now"))}">↻</button></td>
          </tr>`}).join(""),d=Math.round((Date.now()-t._perf.mounted)/1e3),l=window.RPT_API?.stats?window.RPT_API.stats():null,u=`
        <div class="rpt-analyzer-toolbar">
          <div></div>
          <button class="rpt-v2-primary" data-act="refresh-all" aria-label="${r(o("Refresh live data"))}">${r(o("Refresh live data"))}</button>
        </div>
        <p class="rpt-muted">${a("uptime_on_page")}: <strong>${d}s</strong>${s?` · ${a("community_lower")}: <strong>r/${r(s)}</strong>`:""}</p>
        ${l?`<p class="rpt-muted" style="margin:4px 0 10px">
          Reddit JSON cache: <strong>${l.cached}</strong> entries · <strong>${l.hits}</strong> hits · <strong>${l.misses}</strong> fetches · <strong>${l.errors}</strong> errors${l.inflight?` · ${l.inflight} in-flight`:""}
        </p>`:""}
        <div style="max-height:60vh;overflow:auto;border:1px solid var(--border);border-radius:8px">
          <table class="rpt-perf-table" style="width:100%;border-collapse:collapse;font-size:13px">
            <thead><tr>
              <th></th><th style="text-align:left">${a("module")}</th><th>${a("status")}</th><th>${a("last_run")}</th><th>${a("duration")}</th><th></th>
            </tr></thead>
            <tbody>${i}</tbody>
          </table>
        </div>
        <p class="rpt-muted" style="margin-top:10px">
          ${a("legend_perf")}
          ${a("use_panel_lag")}
        </p>`,p=y(o("Performance & status"),u,{wide:!0});p.querySelector('[data-act="refresh-all"]')?.addEventListener("click",()=>{window.RPT_API&&window.RPT_API.clearCache(),p.remove(),t.modules.perfStatus.open()}),p.querySelectorAll("[data-fetch]").forEach(m=>m.addEventListener("click",async()=>{const b=m.dataset.fetch;window.RPT_API&&window.RPT_API.clearCache();try{p.remove(),await t.modules[b]?.run?.({force:!0})}catch(g){console.warn(g)}}))},run(){this.open()}},t.modules.perSubreddit={id:"perSubreddit",name:"Per-subreddit rules",desc:a("per_subreddit_desc"),async open(){const e=f(),c=await t.getPerSub(),s=Object.keys(c).sort(),n=e||s[0]||"",i=c[n]||{},d=Object.values(t.modules).filter(p=>!["perSubreddit","perfStatus","backup"].includes(p.id)).map(p=>`<label class="rpt-persub-row">
          <input type="checkbox" data-id="${r(p.id)}" ${i[p.id]===!1?"":"checked"}>
          <span><strong>${r(o(p.name))}</strong> — <span class="rpt-muted">${r(o(p.desc))}</span></span>
        </label>`).join(""),l=`
        <p class="rpt-muted">${a("persub_rules_desc")}</p>
        <div style="display:flex;gap:8px;margin-bottom:10px">
          <input id="rpt-persub-name" placeholder="${a("subreddit_name_placeholder")}" value="${r(n)}"
            style="flex:1;padding:8px;background:var(--bg-2);border:1px solid var(--border);border-radius:6px;color:var(--fg)">
          <button class="rpt-v2-primary" id="rpt-persub-save">${a("save_rules")}</button>
          <button class="rpt-v2-secondary" id="rpt-persub-clear">${a("clear_for_sub")}</button>
        </div>
        ${s.length?`<p class="rpt-muted">${a("existing_overrides")}: ${s.map(p=>`<code>r/${r(p)}</code>`).join(", ")}</p>`:""}
        <div style="max-height:50vh;overflow:auto;border:1px solid var(--border);border-radius:8px;padding:10px">${d}</div>`,u=y(o("Per-subreddit rules"),l,{wide:!0});u.querySelector("#rpt-persub-save").onclick=async()=>{const p=u.querySelector("#rpt-persub-name").value.trim().toLowerCase().replace(/^r\//,"");if(!p)return h(a("enter_subreddit_name"));const m={...await t.getPerSub()},b={...m[p]||{}};u.querySelectorAll("[data-id]").forEach(g=>{b[g.dataset.id]=g.checked}),m[p]=b,await t.setPerSub(m),h(`${a("rules_saved_for")} r/${p}`),u.remove()},u.querySelector("#rpt-persub-clear").onclick=async()=>{const p=u.querySelector("#rpt-persub-name").value.trim().toLowerCase().replace(/^r\//,""),m={...await t.getPerSub()};delete m[p],await t.setPerSub(m),h(`${a("cleared")} r/${p}`),u.remove()}},run(){this.open()}},t.modules.dataDiag={id:"dataDiag",name:"Data sources & diagnostics",desc:a("data_diag_desc")||"See which Reddit JSON endpoints were used, per-module, with status, timing and errors.",_renderLog(e){if(!e.length)return`<p class="rpt-muted">${r(o("No requests recorded yet — open a module or refresh live data."))}</p>`;const c=e.slice(0,60).map(s=>{const n=s.ok?"●":"✕",i=s.ok?"rpt-badge-on":"rpt-badge-off",d=new Date(s.at).toLocaleTimeString();return`<tr>
          <td><span class="${i}">${n}</span></td>
          <td>${r(s.module||"—")}</td>
          <td style="font-family:ui-monospace,monospace;font-size:11px">${r(s.url.replace(location.origin,""))}</td>
          <td>${s.status||"—"}${s.cached?" <span class='rpt-muted'>cache</span>":""}</td>
          <td>${s.ms} ms</td>
          <td>${d}</td>
          <td>${s.error?`<span class="rpt-muted">${r(s.error)}</span>`:""}</td>
        </tr>`}).join("");return`<table class="rpt-perf-table" style="width:100%;border-collapse:collapse;font-size:12px">
        <thead><tr><th></th><th>${r(o("Module"))}</th><th>${r(o("Endpoint"))}</th><th>${r(o("Status"))}</th><th>${r(o("Duration"))}</th><th>${r(o("Time"))}</th><th>${r(o("Error"))}</th></tr></thead>
        <tbody>${c}</tbody></table>`},_renderPerModule(e){const c=Object.keys(e);return c.length?`<div class="rpt-hub-grid">${c.map(s=>{const n=e[s],i=t.modules[s];return`<div class="rpt-hub-card">
          <div style="padding:10px 14px">
            <strong>${r(o(i?.name||s))}</strong>
            <div class="rpt-muted" style="font-size:12px;margin-top:4px">
              ${n.calls} ${r(o("calls"))} · ${n.errors} ${r(o("errors"))} · ${r(o("last"))}: ${new Date(n.lastAt).toLocaleTimeString()}
            </div>
            <div class="rpt-muted" style="font-size:11px;margin-top:6px;font-family:ui-monospace,monospace;word-break:break-all">
              ${n.endpoints.slice(0,4).map(d=>r(d.replace(location.origin,""))).join("<br>")}
              ${n.endpoints.length>4?`<br>+${n.endpoints.length-4} more`:""}
            </div>
            <button class="rpt-mini-btn" data-fetch-mod="${r(s)}" style="margin-top:8px">${r(o("Fetch latest now"))}</button>
          </div>
        </div>`}).join("")}</div>`:`<p class="rpt-muted">${r(o("No modules have fetched live data yet."))}</p>`},async open(){const e=window.RPT_API;if(!e)return h(o("Live-data client not loaded"));const c=()=>{const i=e.stats();return`
          <div class="rpt-analyzer-toolbar">
            <div class="rpt-muted" style="font-size:12px">
              ${i.cached} ${r(o("cached"))} · ${i.hits} ${r(o("hits"))} · ${i.misses} ${r(o("fetches"))} · ${i.errors} ${r(o("errors"))}
            </div>
            <div class="rpt-btnrow" style="margin:0">
              <button class="rpt-v2-secondary" data-act="clear">${r(o("Clear log"))}</button>
              <button class="rpt-v2-primary" data-act="refresh">${r(o("Refresh live data"))}</button>
            </div>
          </div>
          <h4 class="rpt-section-title">${r(o("Per-module summary"))}</h4>
          ${this._renderPerModule(e.perModule())}
          <h4 class="rpt-section-title">${r(o("Recent Reddit JSON requests"))}</h4>
          <div style="max-height:44vh;overflow:auto;border:1px solid var(--border);border-radius:8px">${this._renderLog(e.log())}</div>
          <p class="rpt-muted" style="margin-top:10px;font-size:11px">
            ${r(o("All requests go directly from your browser to reddit.com. Nothing is sent to any third-party server."))}
          </p>`},s=y(o("Data sources & diagnostics"),c(),{wide:!0}),n=()=>{s.querySelector('[data-act="clear"]')?.addEventListener("click",()=>{e.clearLog(),s.querySelector(".rpt-v2-body").innerHTML=c(),n()}),s.querySelector('[data-act="refresh"]')?.addEventListener("click",()=>{e.clearCache(),s.querySelector(".rpt-v2-body").innerHTML=c(),n()}),s.querySelectorAll("[data-fetch-mod]").forEach(i=>i.addEventListener("click",async()=>{const d=i.dataset.fetchMod;e.clearCache();try{s.remove(),await t.modules[d]?.run?.({force:!0})}catch(l){console.warn(l)}}))};n()},run(){this.open()}},t.modules.backup={id:"backup",name:"Backup & restore",desc:a("backup_restore_desc"),async exportAll(){const e=await new Promise(i=>chrome.storage.local.get(null,i)),c={app:"reddit-power-toolkit",version:"1.9.0",exportedAt:new Date().toISOString(),data:e},s=new Blob([JSON.stringify(c,null,2)],{type:"application/json"}),n=document.createElement("a");n.href=URL.createObjectURL(s),n.download=`rpt-backup-${new Date().toISOString().slice(0,10)}.json`,n.click(),URL.revokeObjectURL(n.href),h(a("backup_downloaded"))},async importFile(e,c={merge:!0}){const s=await e.text();let n;try{n=JSON.parse(s)}catch{throw new Error("Invalid JSON")}if(!n||n.app!=="reddit-power-toolkit"||!n.data||typeof n.data!="object")throw new Error("Not a Reddit Power Toolkit backup");const d={...c.merge?await new Promise(l=>chrome.storage.local.get(null,l)):{},...n.data};await new Promise(l=>chrome.storage.local.set(d,l)),h(`${a("restored")} ${Object.keys(n.data).length} ${a("keys")}`)},async open(){const e=await new Promise(d=>chrome.storage.local.get(null,d)),c=Object.keys(e).filter(d=>d.startsWith("rpt")).sort(),s=new Blob([JSON.stringify(e)]).size,n=`
        <p class="rpt-muted">${a("backup_desc")}</p>
        <div class="rpt-btnrow">
          <button class="rpt-v2-primary" id="rpt-bk-export">${a("export_backup_json")}</button>
          <label class="rpt-v2-secondary" style="cursor:pointer;display:inline-flex;align-items:center;gap:6px">
            ${a("import_backup")}
            <input type="file" id="rpt-bk-import" accept="application/json" style="display:none">
          </label>
          <label style="display:inline-flex;align-items:center;gap:6px;font-size:12px">
            <input type="checkbox" id="rpt-bk-merge" checked> ${a("merge_current_data")}
          </label>
        </div>
        <p class="rpt-muted" style="margin-top:14px">${c.length} ${a("local_keys")} · ${(s/1024).toFixed(1)} KB ${a("total")}</p>
        <details style="margin-top:6px"><summary>${a("contents")}</summary>
          <ul style="max-height:30vh;overflow:auto;font-size:12px">${c.map(d=>`<li><code>${r(d)}</code></li>`).join("")}</ul>
        </details>`,i=y(o("Backup & restore"),n,{wide:!1});i.querySelector("#rpt-bk-export").onclick=()=>this.exportAll(),i.querySelector("#rpt-bk-import").onchange=async d=>{const l=d.target.files?.[0];if(!l)return;const u=i.querySelector("#rpt-bk-merge").checked;try{await this.importFile(l,{merge:u}),i.remove()}catch(p){h(`${a("import_failed")}: ${p.message}`)}}},run(){this.open()}};try{const e=t.openHub;t.openHub=async function(){const c=await t.getEnabled(),s=[["Community",["communityCompare","subAnalyzer","calendar","subHealth","timeline","trendTracker","subGroups","contentExporter"]],["Thread & comments",["miniMap","commentExport","userAnalytics","postAnalytics","copyTools","followKeywords"]],["Filtering & feed",["flairTools","qualityFilter","feedDedup","ageSort","mediaToggle","oldGold","sidebarCleaner"]],["Discovery & knowledge",["bookmarks","savedManager","research","topicTracker","random","history","achievements","wikiNav","resourceCollector"]],["Utilities",["searchEnhancer","linksManager","explainLink","exportLibrary","repostDetector","devMode"]],[a("system_v19"),["perfStatus","dataDiag","perSubreddit","backup"]]],n=`
        <p class="rpt-muted">${a("local_first_tools_desc")}</p>
        <input id="rpt-hub-q" placeholder="${a("search_features")}" style="width:100%;padding:10px;margin-bottom:10px;background:var(--bg-2);border:1px solid var(--border);border-radius:8px;color:var(--fg)">
        ${s.map(([d,l])=>`
          <h3 class="rpt-hub-cat">${r(d)}</h3>
          <div class="rpt-hub-grid">
            ${l.map(u=>{const p=t.modules[u];if(!p)return"";const m=c[u]!==!1;return`<div class="rpt-hub-card ${m?"":"rpt-hub-off"}" data-id="${u}">
                <button class="rpt-hub-run" data-run="${u}">
                  <strong>${r(o(p.name))}</strong>
                  <span>${r(o(p.desc))}</span>
                </button>
                <label class="rpt-hub-toggle" title="${a("enable_disable")}">
                  <input type="checkbox" data-tog="${u}" ${m?"checked":""}>
                </label>
              </div>`}).join("")}
          </div>`).join("")}`,i=y(a("power_features"),n,{wide:!0});i.querySelectorAll("[data-run]").forEach(d=>d.onclick=async()=>{const l=d.dataset.run;if((await t.getEnabled())[l]===!1)return h(a("feature_disabled_turn_on"));try{i.remove(),await t.modules[l].run?.()}catch(p){console.error(p),h(`${a("feature_error")}: ${p.message}`)}}),i.querySelectorAll("[data-tog]").forEach(d=>d.onclick=async l=>{l.stopPropagation(),await w.patch(t.HUB_KEY,{},u=>(u[d.dataset.tog]=d.checked,u)),d.closest(".rpt-hub-card").classList.toggle("rpt-hub-off",!d.checked)}),i.querySelector("#rpt-hub-q").oninput=d=>{const l=d.target.value.toLowerCase();i.querySelectorAll(".rpt-hub-card").forEach(u=>{u.style.display=u.textContent.toLowerCase().includes(l)?"":"none"})}},t.open=t.openHub}catch(e){console.warn("RPT v1.9 hub patch failed",e)}try{const e=$.features?.cmdk;if(e&&typeof e.commands=="function"){const c=e.commands;e.commands=function(){return c.call(this).concat({id:"sys-perf",label:`⚡ ${o("Performance & status")}`,run:()=>t.modules.perfStatus.run()},{id:"sys-diag",label:`⚡ ${o("Data sources & diagnostics")}`,run:()=>t.modules.dataDiag.run()},{id:"sys-persub",label:`⚡ ${o("Per-subreddit rules")}`,run:()=>t.modules.perSubreddit.run()},{id:"sys-backup",label:`⚡ ${o("Backup & restore")}`,run:()=>t.modules.backup.run()})}}}catch{}})();
