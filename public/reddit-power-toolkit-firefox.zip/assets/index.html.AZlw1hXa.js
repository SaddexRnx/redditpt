import{t as n,A as b,i as g}from"./i18n.CtGpBpxN.js";import{r as c,j as e,c as j,R as f}from"./client.gxHn_UGl.js";import{g as y,s as k}from"./storage.Bi64Mgv0.js";/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const N=s=>s.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),d=(...s)=>s.filter((a,r,t)=>!!a&&a.trim()!==""&&t.indexOf(a)===r).join(" ").trim();/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */var v={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const w=c.forwardRef(({color:s="currentColor",size:a=24,strokeWidth:r=2,absoluteStrokeWidth:t,className:o="",children:l,iconNode:m,...h},x)=>c.createElement("svg",{ref:x,...v,width:a,height:a,stroke:s,strokeWidth:t?Number(r)*24/Number(a):r,className:d("lucide",o),...h},[...m.map(([p,u])=>c.createElement(p,u)),...Array.isArray(l)?l:[l]]));/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const i=(s,a)=>{const r=c.forwardRef(({className:t,...o},l)=>c.createElement(w,{ref:l,iconNode:a,className:d(`lucide-${N(s)}`,t),...o}));return r.displayName=`${s}`,r};/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const C=i("ChartColumn",[["path",{d:"M3 3v16a2 2 0 0 0 2 2h16",key:"c24i48"}],["path",{d:"M18 17V9",key:"2bz60n"}],["path",{d:"M13 17V5",key:"1frdt8"}],["path",{d:"M8 17v-3",key:"17ska0"}]]);/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const M=i("ExternalLink",[["path",{d:"M15 3h6v6",key:"1q9fwt"}],["path",{d:"M10 14 21 3",key:"gplh6r"}],["path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6",key:"a6xqqp"}]]);/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const E=i("Power",[["path",{d:"M12 2v10",key:"mnfbl"}],["path",{d:"M18.4 6.6a9 9 0 1 1-12.77.04",key:"obofu9"}]]);/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const L=i("Settings2",[["path",{d:"M20 7h-9",key:"3s1dr2"}],["path",{d:"M14 17H5",key:"gfn3mx"}],["circle",{cx:"17",cy:"17",r:"3",key:"18b49y"}],["circle",{cx:"7",cy:"7",r:"3",key:"dfmy0x"}]]);function A(){const[s,a]=c.useState(null);if(c.useEffect(()=>{y().then(a)},[]),!s)return e.jsx("div",{className:"p-6 text-muted text-sm",children:"Loading…"});const r=async t=>a(await k(t));return e.jsxs("div",{className:"p-4 space-y-3",children:[e.jsxs("header",{className:"flex items-center justify-between",children:[e.jsxs("div",{children:[e.jsx("div",{className:"text-base font-bold tracking-tight text-text",children:n("appName")}),e.jsx("div",{className:"text-[11px] text-muted",children:n("tagline")})]}),e.jsx("img",{src:chrome.runtime.getURL("icons/icon.png"),alt:"",className:"w-8 h-8 rounded-md"})]}),e.jsxs("section",{className:"rpt-card flex items-center justify-between",children:[e.jsxs("div",{children:[e.jsx("div",{className:"text-sm font-semibold text-text",children:n("enable_toolkit")}),e.jsx("div",{className:"text-[11px] text-muted mt-0.5",children:s.enabled?n("status_active"):"Toolkit paused"})]}),e.jsx("button",{onClick:()=>r({enabled:!s.enabled}),className:`w-11 h-6 rounded-full relative transition-colors ${s.enabled?"bg-accent":"bg-panel-3"}`,"aria-pressed":s.enabled,"aria-label":"Enable toolkit",children:e.jsx("span",{className:`absolute top-0.5 w-5 h-5 rounded-full bg-white transition-transform ${s.enabled?"translate-x-[22px]":"translate-x-0.5"}`})})]}),e.jsxs("section",{className:"rpt-card space-y-3",children:[e.jsxs("div",{children:[e.jsx("div",{className:"rpt-label mb-1",children:n("language")}),e.jsx("select",{className:"rpt-input",value:s.lang,onChange:t=>r({lang:t.target.value}),children:b.map(t=>e.jsx("option",{value:t.code,children:t.label},t.code))})]}),e.jsxs("div",{children:[e.jsx("div",{className:"rpt-label mb-1",children:n("theme")}),e.jsx("div",{className:"grid grid-cols-2 gap-2",children:["dark","light"].map(t=>e.jsx("button",{onClick:()=>{r({theme:t}),document.documentElement.setAttribute("data-rpt-theme",t)},className:`rpt-btn ${s.theme===t?"border-accent text-accent":""}`,children:n(t)},t))})]})]}),e.jsxs("section",{className:"grid grid-cols-2 gap-2",children:[e.jsxs("button",{className:"rpt-btn",onClick:()=>chrome.runtime.openOptionsPage(),children:[e.jsx(L,{className:"w-4 h-4"})," ",n("settings")]}),e.jsxs("button",{className:"rpt-btn",onClick:()=>chrome.tabs.create({url:chrome.runtime.getURL("src/pages/analytics/index.html")}),children:[e.jsx(C,{className:"w-4 h-4"})," ",n("analytics")]})]}),e.jsxs("button",{className:"rpt-btn-primary w-full",onClick:async()=>{const[t]=await chrome.tabs.query({active:!0,currentWindow:!0});t?.id&&chrome.tabs.sendMessage(t.id,{type:"rpt:togglePanel"})},children:[e.jsx(E,{className:"w-4 h-4"})," ",n("open_panel")]}),e.jsxs("footer",{className:"flex items-center justify-between text-[11px] text-muted pt-1",children:[e.jsx("span",{children:n("footer_privacy")}),e.jsxs("a",{className:"inline-flex items-center gap-1 hover:text-accent",href:"https://github.com/Saddexrnx/redditpt",target:"_blank",rel:"noreferrer",children:["GitHub ",e.jsx(M,{className:"w-3 h-3"})]})]})]})}await g();j(document.getElementById("root")).render(e.jsx(f.StrictMode,{children:e.jsx(A,{})}));
